# LUMATU API Integration Examples

## Python Client

```python
import requests
import json

class LumatuClient:
    def __init__(self, base_url="http://localhost:8000"):
        self.base_url = base_url
    
    def generate_content(
        self,
        avatar_path: str,
        mode: str,
        voice_path: str = None,
        music_path: str = None
    ):
        """
        Generate avatar content
        
        Args:
            avatar_path: Path to avatar image
            mode: 'reality', 'novela', 'terror', or 'music-video'
            voice_path: Optional path to voice reference
            music_path: Required for music-video mode
        
        Returns:
            dict: Generation response
        """
        files = {
            'avatar': open(avatar_path, 'rb'),
        }
        
        data = {
            'mode': mode,
        }
        
        if voice_path:
            files['voice'] = open(voice_path, 'rb')
        
        if music_path:
            files['music'] = open(music_path, 'rb')
        
        response = requests.post(
            f"{self.base_url}/api/generate",
            files=files,
            data=data
        )
        
        return response.json()

# Usage
client = LumatuClient()

result = client.generate_content(
    avatar_path="my_avatar.jpg",
    mode="reality",
    voice_path="my_voice.mp3"
)

print(f"Session ID: {result['session_id']}")
print(f"Status: {result['message']}")
```

## JavaScript/Node.js Client

```javascript
const axios = require('axios');
const FormData = require('form-data');
const fs = require('fs');

class LumatuClient {
  constructor(baseURL = 'http://localhost:8000') {
    this.baseURL = baseURL;
  }

  async generateContent({
    avatarPath,
    mode,
    voicePath = null,
    musicPath = null
  }) {
    const formData = new FormData();
    
    formData.append('avatar', fs.createReadStream(avatarPath));
    formData.append('mode', mode);
    
    if (voicePath) {
      formData.append('voice', fs.createReadStream(voicePath));
    }
    
    if (musicPath) {
      formData.append('music', fs.createReadStream(musicPath));
    }
    
    const response = await axios.post(
      `${this.baseURL}/api/generate`,
      formData,
      {
        headers: formData.getHeaders()
      }
    );
    
    return response.data;
  }
}

// Usage
const client = new LumatuClient();

client.generateContent({
  avatarPath: './my_avatar.jpg',
  mode: 'novela',
  voicePath: './my_voice.mp3'
}).then(result => {
  console.log('Session ID:', result.session_id);
  console.log('Status:', result.message);
});
```

## WebSocket Client (Real-time Updates)

```javascript
import { io } from 'socket.io-client';

const socket = io('http://localhost:8000');

socket.on('connect', () => {
  console.log('Connected to LUMATU pipeline');
});

socket.on('pipeline_update', (data) => {
  console.log(`Stage: ${data.stage}`);
  console.log(`Progress: ${data.progress}%`);
});

socket.on('generation_complete', (data) => {
  console.log('Generation complete!');
  console.log('Viral Score:', data.viral_score);
  console.log('Video URL:', data.video_url);
  console.log('Metrics:', data.metrics);
});

socket.on('pipeline_error', (data) => {
  console.error('Error:', data.error);
});
```

## cURL Examples

### Generate Reality Show
```bash
curl -X POST http://localhost:8000/api/generate \
  -F "avatar=@avatar.jpg" \
  -F "mode=reality" \
  -F "voice=@voice.mp3"
```

### Generate Music Video
```bash
curl -X POST http://localhost:8000/api/generate \
  -F "avatar=@avatar.jpg" \
  -F "mode=music-video" \
  -F "music=@song.mp3" \
  -F "voice=@voice.mp3"
```

### Generate Horror Content
```bash
curl -X POST http://localhost:8000/api/generate \
  -F "avatar=@avatar.jpg" \
  -F "mode=terror"
```

## Response Format

### Success Response
```json
{
  "success": true,
  "session_id": "20240127_143022",
  "message": "Generation started"
}
```

### Pipeline Update (WebSocket)
```json
{
  "stage": "Identity Validation",
  "progress": 10
}
```

### Generation Complete (WebSocket)
```json
{
  "success": true,
  "session_id": "20240127_143022",
  "viral_score": 0.87,
  "video_url": "/outputs/20240127_143022/final.mp4",
  "metrics": {
    "identity_consistency": 0.92,
    "hook_power": 0.82,
    "emotion_density": 0.88,
    "meme_timing": 0.91,
    "rhythm": 0.95,
    "novelty": 0.78
  }
}
```

## Error Handling

```python
try:
    result = client.generate_content(
        avatar_path="avatar.jpg",
        mode="reality"
    )
except requests.exceptions.RequestException as e:
    print(f"Request failed: {e}")
except Exception as e:
    print(f"Unexpected error: {e}")
```

## Rate Limiting

- Max concurrent generations: 5
- Max file size: 50MB per file
- Timeout: 10 minutes per generation

## Authentication (Future)

```python
headers = {
    'Authorization': 'Bearer YOUR_API_KEY'
}

response = requests.post(
    url,
    files=files,
    data=data,
    headers=headers
)
```
