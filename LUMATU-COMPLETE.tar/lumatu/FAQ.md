# LUMATU - FAQ & TROUBLESHOOTING

## Frequently Asked Questions

### General

**Q: What is LUMATU?**
A: LUMATU is an AI-powered platform that generates viral video content using your avatar. Upload a photo, select a mode (Reality, Novela, Terror, or Music Video), and LUMATU creates professional-quality videos with Netflix-level editing, automatic meme injection, and viral score prediction.

**Q: Do I need technical skills to use LUMATU?**
A: No! LUMATU is designed for everyone. Simply upload your avatar image, choose a mode, and click generate. The AI handles everything else.

**Q: How long does it take to generate a video?**
A: Most videos are ready in 2-5 minutes, depending on complexity and server load.

**Q: What file formats are supported?**
A: 
- Images: JPG, PNG, WebP (up to 10MB)
- Audio: MP3, WAV, M4A (up to 50MB)
- Output: MP4 (H.264, 1080x1920)

**Q: Is there a free trial?**
A: Yes! Free tier includes 3 generations per month. Pro trial available for 14 days.

---

### Features

**Q: What are the different content modes?**
A: 
- **Reality Show**: Drama, conflicts, emotional moments
- **Novela**: Romantic storytelling with dramatic arcs
- **Terror**: Horror content with suspense
- **Music Video**: Lip-synced performance videos

**Q: What is the viral score?**
A: A 0-100 score predicting content virality based on:
- Hook Power (25%)
- Emotion Density (20%)
- Identity Clarity (15%)
- Meme Timing (15%)
- Rhythm (15%)
- Novelty (10%)

Scores ≥75 are "viral ready", 60-74 need adjustment, <60 are blocked.

**Q: Can I use multiple avatars in one video?**
A: Currently, LUMATU supports single-avatar content. Multi-avatar support is planned for Phase 4 (see ROADMAP.md).

**Q: Can I customize the script?**
A: The AI generates scripts automatically. Custom script input is planned for future releases.

**Q: How does voice cloning work?**
A: Upload a voice reference (optional), and LUMATU uses it to synthesize narrator commentary that sounds like you.

**Q: What music can I use for music videos?**
A: Upload your own royalty-free music or original tracks. LUMATU checks for copyright violations automatically.

---

### Technical

**Q: What are the system requirements?**
A: 
- **Development**: Node.js 18+, Python 3.10+
- **Browser**: Chrome, Firefox, Safari (latest 2 versions)
- **Network**: 10+ Mbps recommended
- **Storage**: 2GB free space for uploads/outputs

**Q: Which video engines does LUMATU use?**
A: 
- **Runway ML**: Reality shows and novelas (cinematic quality)
- **Pika Labs**: Terror/horror (experimental effects)
- **Luma AI**: Music videos (perfect lip-sync)

**Q: Can I run LUMATU locally?**
A: Yes! Use `./deploy.sh` for local development. See QUICKSTART.md for details.

**Q: How do I deploy to production?**
A: Multiple options available:
- Vercel + Railway (recommended)
- AWS (ECS + CloudFront)
- Docker Compose (self-hosted)
- Kubernetes (enterprise)

See PRODUCTION.md for detailed instructions.

**Q: Does LUMATU work offline?**
A: No. LUMATU requires internet connection to access AI video generation APIs.

---

### Privacy & Security

**Q: Is my avatar image stored?**
A: Yes, temporarily. Uploads are deleted after 7 days, final videos after 30 days. Enterprise users can customize retention policies.

**Q: Is my data private?**
A: Yes. LUMATU is GDPR compliant. You can request data export or deletion anytime.

**Q: Can others see my videos?**
A: No, unless you share them. All generations are private by default.

**Q: How is my payment information secured?**
A: LUMATU uses Stripe for payments. We never store your credit card information.

**Q: What content is prohibited?**
A: 
- NSFW/explicit content
- Hate speech or violence
- Deepfakes of real people without consent
- Copyright-protected material
- Misinformation

---

### Billing & Subscriptions

**Q: How much does LUMATU cost?**
A: 
- **Free**: 3 generations/month, 720p, watermarked
- **Pro** ($19/mo): Unlimited, 1080p, no watermark
- **Business** ($99/mo): API access, white-label
- **Enterprise**: Custom pricing

**Q: Can I cancel anytime?**
A: Yes! Cancel your subscription anytime from your account settings. No questions asked.

**Q: What payment methods are accepted?**
A: Credit cards (Visa, Mastercard, Amex), debit cards, and PayPal.

**Q: Do you offer refunds?**
A: Yes, within 14 days if unsatisfied with the service.

**Q: What happens if I exceed my quota?**
A: Free users must wait until next month or upgrade. Pro users have unlimited generations.

---

## Troubleshooting

### Upload Issues

**Problem: "File too large" error**
Solution:
```
1. Compress your image/audio file
2. Maximum sizes: Images 10MB, Audio 50MB
3. Use online tools like TinyPNG or compress.com
```

**Problem: "Invalid file type" error**
Solution:
```
1. Convert to supported format
2. Images: JPG, PNG, WebP
3. Audio: MP3, WAV, M4A
4. Use CloudConvert or similar
```

**Problem: "Upload failed" error**
Solution:
```
1. Check internet connection
2. Try a different browser
3. Clear browser cache
4. Disable browser extensions
5. Try incognito/private mode
```

---

### Generation Issues

**Problem: Generation stuck at specific stage**
Solution:
```
1. Wait 5 minutes (may be processing)
2. Refresh page to check status
3. Check WebSocket connection (browser console)
4. If stuck >10 min, contact support
```

**Problem: "Identity validation failed"**
Solution:
```
1. Use clear, well-lit photo
2. Face should be visible and centered
3. Avoid sunglasses, masks, or obstructions
4. Minimum resolution: 512x512
5. Try different photo
```

**Problem: Low viral score (<0.6)**
Solution:
```
1. Check avatar image quality
2. Try different mode
3. Add voice reference for better engagement
4. Use music video mode (typically higher scores)
5. Review the metrics to identify weak areas
```

**Problem: "Copyright violation detected"**
Solution:
```
1. Use royalty-free music only
2. Check music licensing
3. Use original compositions
4. Try Epidemic Sound or Artlist
```

---

### Connection Issues

**Problem: WebSocket not connecting**
Solution:
```
1. Check firewall settings
2. Ensure port 8000 is accessible
3. Verify CORS configuration
4. Check browser console for errors
5. Try different network
```

**Problem: "Connection timeout" error**
Solution:
```
1. Check internet speed (need 10+ Mbps)
2. Close other bandwidth-heavy apps
3. Try wired connection instead of WiFi
4. Check server status
5. Wait and retry in few minutes
```

**Problem: API errors (500, 503)**
Solution:
```
1. Server may be under heavy load
2. Wait 5-10 minutes and retry
3. Check status page
4. Contact support if persists
```

---

### Video Quality Issues

**Problem: Blurry or low-quality output**
Solution:
```
1. Use higher resolution avatar (1080p+)
2. Upgrade to Pro for HD output
3. Check source image quality
4. Avoid heavily compressed images
```

**Problem: Face doesn't match avatar**
Solution:
```
1. Use clear, front-facing photo
2. Good lighting is essential
3. Avoid extreme angles
4. Try different photo
5. Enable "strict mode" if available
```

**Problem: Poor lip sync in music videos**
Solution:
```
1. Use clear audio with minimal background noise
2. Ensure music has clear vocals
3. Try different music track
4. Luma engine works best for lip sync
```

**Problem: Memes don't fit content**
Solution:
```
Currently automatic. Manual meme selection 
coming in future update. Provide feedback to 
help improve AI meme detection.
```

---

### Performance Issues

**Problem: Slow page loading**
Solution:
```
1. Clear browser cache
2. Disable unnecessary extensions
3. Close unused tabs
4. Check internet speed
5. Try different browser
```

**Problem: Video generation taking >10 minutes**
Solution:
```
1. Check server load in dashboard
2. Peak hours may be slower
3. Try generating during off-peak
4. Consider upgrading tier for priority
```

**Problem: Dashboard not updating**
Solution:
```
1. Refresh page
2. Check WebSocket connection
3. Clear cache and cookies
4. Try different browser
5. Check browser console for errors
```

---

### Deployment Issues

**Problem: Docker build failing**
Solution:
```bash
# Clean Docker cache
docker system prune -a

# Rebuild without cache
docker-compose build --no-cache

# Check Docker version (need 20.10+)
docker --version
```

**Problem: Port already in use**
Solution:
```bash
# Kill process on port 3000
lsof -ti:3000 | xargs kill -9

# Or change port in docker-compose.yml
ports:
  - "3001:3000"  # Map to different port
```

**Problem: Environment variables not loading**
Solution:
```bash
# Check .env file exists
ls -la .env

# Verify format (no spaces around =)
# Correct:   API_KEY=abc123
# Incorrect: API_KEY = abc123

# Reload environment
source .env
```

**Problem: Database connection failed**
Solution:
```bash
# Check PostgreSQL is running
docker-compose ps

# Verify credentials in .env
DATABASE_URL=postgresql://user:pass@host:5432/db

# Reset database
docker-compose down -v
docker-compose up -d
```

---

### API Issues

**Problem: 401 Unauthorized**
Solution:
```python
# Check API key is set
headers = {
    "Authorization": f"Bearer {API_KEY}"
}

# Verify key is valid
# Regenerate key if needed
```

**Problem: 429 Too Many Requests**
Solution:
```python
# Respect rate limits
# Free: 10/hour
# Pro: 100/hour
# Enterprise: Unlimited

# Implement exponential backoff
import time

def retry_with_backoff(func, max_retries=3):
    for i in range(max_retries):
        try:
            return func()
        except RateLimitError:
            time.sleep(2 ** i)
```

**Problem: Invalid response format**
Solution:
```python
# Check API version
# Current: v1

# Verify endpoint
# Correct: /api/v1/generate
# Incorrect: /api/generate

# Check request format matches docs
```

---

## Getting Help

### Self-Service
1. Check this FAQ
2. Review documentation (README.md)
3. Search GitHub issues
4. Check status page

### Community Support
- GitHub Discussions
- Discord server
- Reddit r/LUMATU
- Twitter @LUMATUai

### Paid Support
- **Pro**: Email support (24-48h response)
- **Business**: Priority email (12-24h response)
- **Enterprise**: Dedicated support (4h response)

### Contact
- Email: support@lumatu.ai
- Twitter: @LUMATUai
- GitHub: github.com/lumatu/lumatu

---

## Common Error Messages

### "Avatar validation failed"
**Cause**: Poor image quality or no face detected
**Fix**: Use clear, well-lit, front-facing photo

### "Insufficient credits"
**Cause**: Credit balance too low
**Fix**: Purchase more credits or upgrade plan

### "Generation timeout"
**Cause**: Server overload or network issue
**Fix**: Wait and retry, or contact support

### "Copyright violation detected"
**Cause**: Copyrighted music detected
**Fix**: Use royalty-free or original music

### "Rate limit exceeded"
**Cause**: Too many requests
**Fix**: Wait before retrying, or upgrade plan

### "Server error (500)"
**Cause**: Internal server issue
**Fix**: Check status page, retry in 5 minutes

---

## Tips for Best Results

### Avatar Images
✓ High resolution (1080p+)
✓ Good lighting
✓ Clear face visibility
✓ Neutral background
✓ Front-facing angle

✗ Blurry or pixelated
✗ Dark or backlit
✗ Side angles
✗ Sunglasses or masks
✗ Group photos

### Voice Reference
✓ Clear speech
✓ Minimal background noise
✓ 10+ seconds duration
✓ Natural tone

✗ Music playing
✗ Crowd noise
✗ Phone quality
✗ Too short

### Mode Selection
- **Reality**: Personal stories, drama
- **Novela**: Romance, relationships
- **Terror**: Scary stories, horror
- **Music Video**: Songs, performances

### Viral Optimization
- Start with strong hook (first 3s)
- Use emotional storytelling
- Include surprise elements
- Leverage trending topics
- Test different modes

---

**Still having issues? Contact support@lumatu.ai with:**
1. Error message
2. Steps to reproduce
3. Browser/OS version
4. Screenshots if applicable
