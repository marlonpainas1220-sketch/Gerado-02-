# LUMATU PRODUCTION DEPLOYMENT GUIDE

## Pre-Deployment Checklist

### 1. Environment Configuration
- [ ] API keys configured (.env file)
- [ ] Database/storage credentials
- [ ] CORS origins set correctly
- [ ] WebSocket URL configured
- [ ] SSL certificates ready

### 2. Performance Optimization
- [ ] Frontend build optimized (`npm run build`)
- [ ] Backend worker processes configured
- [ ] CDN configured for static assets
- [ ] Database indexes created
- [ ] Caching layer enabled

### 3. Security
- [ ] Rate limiting enabled
- [ ] File upload validation
- [ ] API authentication configured
- [ ] HTTPS enforced
- [ ] Security headers configured

### 4. Monitoring
- [ ] Error tracking (Sentry/Rollbar)
- [ ] Performance monitoring
- [ ] Uptime monitoring
- [ ] Log aggregation
- [ ] Alert system configured

## Deployment Options

### Option 1: Vercel + Railway (Recommended)

**Frontend (Vercel):**
```bash
cd frontend
vercel --prod

# Configure environment variables:
# NEXT_PUBLIC_API_URL=https://your-backend.railway.app
```

**Backend (Railway):**
```bash
cd backend
railway login
railway init
railway up

# Configure environment variables in Railway dashboard
```

**Advantages:**
- Auto-scaling
- Built-in CI/CD
- Easy rollbacks
- Affordable

### Option 2: AWS (Production Grade)

**Architecture:**
```
CloudFront → S3 (Frontend)
      ↓
  ALB → ECS/Fargate (Backend)
      ↓
  RDS (Metadata) + S3 (Files)
```

**Setup:**

1. **Frontend (S3 + CloudFront)**
```bash
cd frontend
npm run build

aws s3 sync out/ s3://lumatu-frontend
aws cloudfront create-invalidation --distribution-id XXX --paths "/*"
```

2. **Backend (ECS)**
```bash
# Build and push Docker image
docker build -t lumatu-backend backend/
docker tag lumatu-backend:latest XXX.dkr.ecr.us-east-1.amazonaws.com/lumatu-backend:latest
docker push XXX.dkr.ecr.us-east-1.amazonaws.com/lumatu-backend:latest

# Deploy to ECS
aws ecs update-service --cluster lumatu --service backend --force-new-deployment
```

3. **Infrastructure as Code (Terraform)**
```hcl
# main.tf
resource "aws_ecs_cluster" "lumatu" {
  name = "lumatu-cluster"
}

resource "aws_ecs_service" "backend" {
  name            = "lumatu-backend"
  cluster         = aws_ecs_cluster.lumatu.id
  task_definition = aws_ecs_task_definition.backend.arn
  desired_count   = 3
  
  load_balancer {
    target_group_arn = aws_lb_target_group.backend.arn
    container_name   = "lumatu-backend"
    container_port   = 8000
  }
}
```

### Option 3: Docker Compose (Self-Hosted)

**server.yml:**
```yaml
version: '3.8'

services:
  frontend:
    image: lumatu-frontend:latest
    restart: always
    ports:
      - "80:3000"
    environment:
      - NEXT_PUBLIC_API_URL=https://api.lumatu.com
    
  backend:
    image: lumatu-backend:latest
    restart: always
    ports:
      - "8000:8000"
    environment:
      - POE_API_KEY=${POE_API_KEY}
      - RUNWAY_API_KEY=${RUNWAY_API_KEY}
    volumes:
      - ./uploads:/app/uploads
      - ./outputs:/app/outputs
    
  nginx:
    image: nginx:alpine
    restart: always
    ports:
      - "443:443"
    volumes:
      - ./nginx.conf:/etc/nginx/nginx.conf
      - ./ssl:/etc/nginx/ssl

volumes:
  uploads:
  outputs:
```

**Deploy:**
```bash
docker-compose -f server.yml up -d
```

## Domain Configuration

### DNS Records
```
A     lumatu.com           → Frontend IP
A     api.lumatu.com       → Backend IP
CNAME www.lumatu.com       → lumatu.com
```

### SSL Certificate (Let's Encrypt)
```bash
certbot --nginx -d lumatu.com -d www.lumatu.com -d api.lumatu.com
```

## Nginx Configuration

```nginx
# /etc/nginx/sites-available/lumatu
upstream backend {
    server 127.0.0.1:8000;
}

server {
    listen 443 ssl http2;
    server_name api.lumatu.com;
    
    ssl_certificate /etc/letsencrypt/live/api.lumatu.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/api.lumatu.com/privkey.pem;
    
    location / {
        proxy_pass http://backend;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
    
    location /outputs/ {
        alias /var/lumatu/outputs/;
        expires 7d;
    }
}

server {
    listen 443 ssl http2;
    server_name lumatu.com www.lumatu.com;
    
    ssl_certificate /etc/letsencrypt/live/lumatu.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/lumatu.com/privkey.pem;
    
    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

## Environment Variables

**Production .env:**
```env
# API Keys
POE_API_KEY=psk-xxxxx
RUNWAY_API_KEY=rw-xxxxx
PIKA_API_KEY=pk-xxxxx
LUMA_API_KEY=lm-xxxxx

# Database
DATABASE_URL=postgresql://user:pass@host:5432/lumatu

# Storage
UPLOAD_DIR=/var/lumatu/uploads
OUTPUT_DIR=/var/lumatu/outputs
S3_BUCKET=lumatu-videos

# Redis Cache
REDIS_URL=redis://localhost:6379

# Monitoring
SENTRY_DSN=https://xxxxx@sentry.io/xxxxx
LOG_LEVEL=INFO

# Security
SECRET_KEY=your-secret-key-here
ALLOWED_ORIGINS=https://lumatu.com,https://www.lumatu.com
```

## Performance Tuning

### Backend (Gunicorn)
```bash
gunicorn main:socket_app \
  --workers 4 \
  --worker-class uvicorn.workers.UvicornWorker \
  --bind 0.0.0.0:8000 \
  --timeout 300 \
  --keep-alive 5 \
  --max-requests 1000 \
  --max-requests-jitter 50
```

### Frontend (PM2)
```bash
pm2 start npm --name "lumatu-frontend" -- start
pm2 startup
pm2 save
```

## Monitoring Setup

### Error Tracking (Sentry)
```python
# backend/main.py
import sentry_sdk
from sentry_sdk.integrations.fastapi import FastApiIntegration

sentry_sdk.init(
    dsn=os.getenv("SENTRY_DSN"),
    integrations=[FastApiIntegration()],
    traces_sample_rate=0.1
)
```

### Metrics (Prometheus)
```python
# backend/monitoring.py
from prometheus_client import Counter, Histogram

generation_counter = Counter('generations_total', 'Total generations')
viral_score_histogram = Histogram('viral_score', 'Viral scores distribution')
```

### Logging
```python
# backend/logging_config.py
LOGGING = {
    'version': 1,
    'handlers': {
        'file': {
            'class': 'logging.handlers.RotatingFileHandler',
            'filename': 'lumatu.log',
            'maxBytes': 10485760,  # 10MB
            'backupCount': 5
        }
    },
    'root': {
        'level': 'INFO',
        'handlers': ['file']
    }
}
```

## Backup Strategy

### Automated Backups
```bash
#!/bin/bash
# backup.sh

# Database backup
pg_dump lumatu > /backups/db_$(date +%Y%m%d).sql

# Files backup
rsync -av /var/lumatu/outputs/ /backups/outputs/

# Upload to S3
aws s3 sync /backups/ s3://lumatu-backups/

# Cleanup old backups (keep 30 days)
find /backups/ -mtime +30 -delete
```

**Cron job:**
```cron
0 2 * * * /usr/local/bin/backup.sh
```

## Scaling Strategy

### Horizontal Scaling
```yaml
# kubernetes/deployment.yml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: lumatu-backend
spec:
  replicas: 5
  selector:
    matchLabels:
      app: lumatu-backend
  template:
    spec:
      containers:
      - name: backend
        image: lumatu-backend:latest
        resources:
          requests:
            memory: "512Mi"
            cpu: "500m"
          limits:
            memory: "2Gi"
            cpu: "2000m"
```

### Auto-scaling
```yaml
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: lumatu-backend-hpa
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: lumatu-backend
  minReplicas: 2
  maxReplicas: 10
  metrics:
  - type: Resource
    resource:
      name: cpu
      target:
        type: Utilization
        averageUtilization: 70
```

## Health Checks

### Backend Health Endpoint
```python
@app.get("/health")
async def health_check():
    return {
        "status": "healthy",
        "version": "1.0.0",
        "timestamp": datetime.now().isoformat()
    }
```

### Monitoring Script
```bash
#!/bin/bash
# health_check.sh

URL="https://api.lumatu.com/health"
RESPONSE=$(curl -s -o /dev/null -w "%{http_code}" $URL)

if [ $RESPONSE != "200" ]; then
    echo "Health check failed: $RESPONSE"
    # Send alert
    curl -X POST https://hooks.slack.com/... \
      -d '{"text":"LUMATU API is down!"}'
fi
```

## Rollback Procedure

### Quick Rollback
```bash
# Vercel
vercel rollback

# Railway
railway rollback

# Docker
docker-compose down
docker-compose -f docker-compose.prod.yml up -d --build

# Kubernetes
kubectl rollout undo deployment/lumatu-backend
```

## Post-Deployment Verification

```bash
# Test endpoints
curl https://api.lumatu.com/health
curl https://lumatu.com

# Check logs
tail -f /var/log/lumatu/app.log

# Monitor metrics
python cli.py analytics --detailed

# Run smoke tests
pytest tests/smoke_tests.py --env=production
```

## Maintenance Window

Schedule regular maintenance:
- Weekly: Security updates
- Monthly: Dependency updates
- Quarterly: Performance optimization review

---

**Production deployment complete. Monitor for 24 hours post-deployment.**
