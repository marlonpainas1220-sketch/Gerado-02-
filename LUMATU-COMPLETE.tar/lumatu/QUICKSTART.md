# LUMATU - Quick Start Guide

## 5-Minute Setup

### Step 1: Clone & Navigate
```bash
cd lumatu
```

### Step 2: Run Deployment Script
```bash
chmod +x deploy.sh
./deploy.sh
```

The script will:
- Install all dependencies
- Setup backend (Python virtualenv)
- Setup frontend (Node modules)
- Start both services

### Step 3: Access Application
- Frontend: http://localhost:3000
- Backend API: http://localhost:8000

## Manual Setup (Alternative)

### Backend
```bash
cd backend
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
python main.py
```

### Frontend
```bash
cd frontend
npm install
npm run dev
```

## First Content Generation

1. Open http://localhost:3000
2. Upload avatar image (required)
3. Upload voice reference (optional)
4. Select mode:
   - Reality Show
   - Novela
   - Terror
   - Music Video
5. (Music Video only) Upload music file
6. Click "Generate"
7. Watch real-time pipeline progress
8. Review viral score and download video

## Configuration

### API Keys (Optional for Demo)

Create `.env` in backend/:
```env
POE_API_KEY=your_key
RUNWAY_API_KEY=your_key
PIKA_API_KEY=your_key
LUMA_API_KEY=your_key
```

Demo mode works without API keys (uses simulated responses).

## Architecture Overview

```
User → Frontend (React) → Backend (FastAPI) → AI Agents
                    ↓
            WebSocket Updates
                    ↓
         Real-time Progress UI
```

## Features

### Automated Pipeline
1. ✓ Identity Validation
2. ✓ Script Generation
3. ✓ Emotional Arc Planning
4. ✓ Frame Planning
5. ✓ Video Generation (Runway/Pika/Luma)
6. ✓ Netflix-Level Editing
7. ✓ Narrator Integration
8. ✓ Viral Score Analysis

### Viral Score Formula
```
Score = 0.25×Hook + 0.20×Emotion + 0.15×Identity + 
        0.15×Memes + 0.15×Rhythm + 0.10×Novelty

Thresholds:
  ≥0.75 → Publish
  0.60-0.74 → Optimize
  <0.60 → Block
```

## Troubleshooting

### Port Already in Use
```bash
# Kill process on port 3000
lsof -ti:3000 | xargs kill -9

# Kill process on port 8000
lsof -ti:8000 | xargs kill -9
```

### Module Not Found
```bash
# Backend
cd backend
pip install -r requirements.txt

# Frontend
cd frontend
npm install
```

### WebSocket Connection Failed
- Check backend is running on port 8000
- Check CORS configuration
- Verify no firewall blocking

## Production Deployment

### Vercel (Frontend)
```bash
cd frontend
vercel --prod
```

### Railway (Backend)
```bash
cd backend
railway up
```

### Docker
```bash
docker-compose up -d
```

## Next Steps

1. Review README.md for full documentation
2. Check API_EXAMPLES.md for integration examples
3. Run tests: `cd backend && pytest tests/`
4. Customize agents in `backend/orchestrator/agents/`
5. Adjust viral score weights in `backend/services/viral.py`

## Support

- Documentation: README.md
- API Examples: API_EXAMPLES.md
- Issues: GitHub Issues
- Email: support@lumatu.ai

---

**You're ready to generate viral avatar content!** 🚀
