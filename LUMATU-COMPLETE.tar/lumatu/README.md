# LUMATU - AI Avatar Content Generator

Full-stack production-ready web application for generating viral content using AI avatars.

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                         FRONTEND                            │
│  Next.js 14 + React + Tailwind + WebSocket                 │
│                                                             │
│  Components:                                                │
│  - Avatar Upload                                            │
│  - Mode Selection (Reality/Novela/Terror/Music)            │
│  - Real-time Pipeline Status                               │
│  - Viral Score Dashboard                                   │
└─────────────────────────────────────────────────────────────┘
                            ↕
┌─────────────────────────────────────────────────────────────┐
│                         BACKEND                             │
│  FastAPI + Python + WebSocket + AsyncIO                    │
│                                                             │
│  Orchestrator:                                              │
│  - AvatarBrain (Poe bot delegation)                        │
│  - GenerationPipeline (async workflow)                     │
│                                                             │
│  Services:                                                  │
│  - VideoEngine (Runway/Pika/Luma)                          │
│  - IdentityValidator (consistency checks)                  │
│  - ViralScoreEngine (prediction)                           │
│                                                             │
│  Agents:                                                    │
│  - ScriptWriter                                            │
│  - EmotionalArcArchitect                                   │
│  - NetflixEditor                                           │
│  - SarcasticNarrator                                       │
└─────────────────────────────────────────────────────────────┘
                            ↕
┌─────────────────────────────────────────────────────────────┐
│                    EXTERNAL SERVICES                        │
│  - Poe Internal Bots (Claude Sonnet 4.5)                   │
│  - Runway ML (cinematic video)                             │
│  - Pika Labs (horror/experimental)                         │
│  - Luma AI (music video + lip sync)                        │
└─────────────────────────────────────────────────────────────┘
```

## Features

### Avatar Tab
- Upload avatar image (mandatory)
- Upload voice reference (optional)
- Select content mode:
  - Reality Show
  - Novela
  - Terror/Horror
  - Music Video (requires music file)
- Real-time generation pipeline
- Viral score analysis
- Netflix-level editing

### AI Pipeline

```
[UPLOAD] → [IDENTITY VALIDATION] → [MODE SELECTION]
    ↓
[AI SCRIPT GENERATION] → [EMOTIONAL ARC 30/60/90]
    ↓
[FRAME PLANNING] → [VIDEO ENGINE SELECTION]
    ↓
[FRAME GENERATION] → [IDENTITY CONSISTENCY CHECK]
    ↓
[NETFLIX EDITING] → [NARRATOR INTEGRATION]
    ↓
[MEME INJECTION] → [VIRAL SCORE]
    ↓
[DECISION: <0.6 BLOCK | 0.6-0.75 ADJUST | >0.75 PUBLISH]
```

## Installation

### Prerequisites
- Node.js 18+
- Python 3.10+
- npm or yarn

### Frontend Setup

```bash
cd lumatu/frontend
npm install
npm run dev
```

Frontend runs on: http://localhost:3000

### Backend Setup

```bash
cd lumatu/backend
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate
pip install -r requirements.txt
python main.py
```

Backend runs on: http://localhost:8000

## Configuration

### Environment Variables

Create `.env` file in backend:

```env
# Poe API (for bot delegation)
POE_API_KEY=your_poe_api_key

# Video Generation APIs
RUNWAY_API_KEY=your_runway_key
PIKA_API_KEY=your_pika_key
LUMA_API_KEY=your_luma_key

# Storage
UPLOAD_DIR=uploads
OUTPUT_DIR=outputs
```

## Viral Score Formula

```
VIRAL_SCORE = 
  0.25 × Hook Power +
  0.20 × Emotion Density +
  0.15 × Identity Clarity +
  0.15 × Meme Timing +
  0.15 × Rhythm +
  0.10 × Novelty

Thresholds:
  ≥ 0.75 → VIRAL READY (publish)
  0.60-0.74 → NEEDS ADJUSTMENT (auto-optimize)
  < 0.60 → BLOCKED (reject)
```

## Video Engine Selection

| Mode | Engine | Reason |
|------|--------|--------|
| Music Video | Luma | Perfect lip-sync capability |
| Horror/Terror | Pika | Experimental, unstable aesthetic |
| Reality Show | Runway | Cinematic, natural acting |
| Novela | Runway | Dramatic lighting, emotion capture |

## Frame Prompt Templates

### Runway (Drama/Reality)
```
Ultra-realistic cinematic vertical video (9:16).
Same avatar face as reference, DO NOT CHANGE.
Natural acting, handheld camera, cinematic light.
Scene: {description}
Emotion: {emotion}
Duration: {duration}s
```

### Pika (Horror)
```
Dark horror cinematic vertical video.
Same avatar identity, high tension, unstable camera.
Scene: {description}
Emotion: {emotion}
Duration: {duration}s
```

### Luma (Music Video)
```
Photorealistic music video with PERFECT lip sync.
Avatar face must match reference exactly.
Stylized cinematic movement.
Scene: {description}
Duration: {duration}s
```

## Testing

```bash
cd backend
pytest tests/test_suite.py -v
```

Test coverage:
- Identity validation
- Viral score calculation
- Script generation
- Emotional arc planning
- Pipeline integration

## Deployment

### Vercel (Frontend)

```bash
cd frontend
vercel deploy --prod
```

### Railway/Fly.io (Backend)

```bash
cd backend

# Railway
railway up

# Fly.io
fly deploy
```

### Docker (Full Stack)

```bash
# Build
docker-compose build

# Run
docker-compose up -d
```

## API Endpoints

### POST /api/generate
Generate avatar content

**Request:**
```
FormData:
  - avatar: File (required)
  - mode: string (required) [reality|novela|terror|music-video]
  - voice: File (optional)
  - music: File (required for music-video mode)
```

**Response:**
```json
{
  "success": true,
  "session_id": "20240127_143022",
  "message": "Generation started"
}
```

### WebSocket Events

**Client → Server:**
- `connect`: Establish connection

**Server → Client:**
- `pipeline_update`: Real-time progress
  ```json
  {
    "stage": "Identity Validation",
    "progress": 10
  }
  ```

- `generation_complete`: Final result
  ```json
  {
    "success": true,
    "viral_score": 0.87,
    "video_url": "/outputs/session_id/final.mp4",
    "metrics": { ... }
  }
  ```

## Project Structure

```
lumatu/
├── frontend/
│   ├── app/
│   │   ├── avatar/
│   │   │   ├── page.tsx
│   │   │   ├── components/
│   │   │   │   ├── AvatarUpload.tsx
│   │   │   │   ├── VoiceUpload.tsx
│   │   │   │   ├── ModeSelector.tsx
│   │   │   │   ├── MusicUpload.tsx
│   │   │   │   ├── GenerationPanel.tsx
│   │   │   │   └── Dashboard.tsx
│   │   │   └── hooks/
│   │   │       └── useWebSocket.ts
│   │   ├── layout.tsx
│   │   ├── page.tsx
│   │   └── globals.css
│   ├── package.json
│   ├── tailwind.config.js
│   └── next.config.js
│
└── backend/
    ├── main.py
    ├── orchestrator/
    │   ├── brain.py
    │   ├── pipeline.py
    │   └── agents/
    │       ├── script_writer.py
    │       └── emotional_arc.py
    ├── services/
    │   ├── video.py
    │   ├── identity.py
    │   └── viral.py
    ├── tests/
    │   └── test_suite.py
    └── requirements.txt
```

## Performance

- Frontend: <1s page load
- Backend: Async pipeline (non-blocking)
- WebSocket: Real-time updates
- Video generation: 2-5 min per 60s video
- Identity validation: <500ms
- Viral score: <200ms

## Monitoring

Dashboard metrics:
- Viral score gauge (0-100)
- Emotional arc graph
- Identity consistency %
- Frame rejection logs
- Narrator usage timeline
- Export capabilities

## Troubleshooting

### Identity Drift
If avatar consistency falls below 85%:
- Regenerate frame with stricter prompts
- Apply auto-correction filters
- Increase identity weight in prompt

### Low Viral Score
Auto-optimization triggers:
- Enhance hook (first 3s)
- Add dynamic captions
- Optimize rhythm/pacing
- Inject more meme moments

### WebSocket Issues
- Check CORS configuration
- Verify backend is running
- Check network firewall rules

## License

Proprietary - LUMATU 2026

## Support

For issues or questions:
- GitHub Issues
- Email: support@lumatu.ai
