# LUMATU SECURITY & COMPLIANCE

## Security Architecture

### 1. Input Validation

```python
# backend/security/validation.py

class SecurityValidator:
    """
    Validate all user inputs
    """
    
    ALLOWED_IMAGE_TYPES = ['image/jpeg', 'image/png', 'image/webp']
    ALLOWED_AUDIO_TYPES = ['audio/mpeg', 'audio/wav', 'audio/mp4']
    MAX_FILE_SIZE = 50 * 1024 * 1024  # 50MB
    
    async def validate_upload(
        self,
        file: UploadFile,
        file_type: str
    ) -> Dict:
        """
        Validate uploaded file
        """
        # Check file size
        if file.size > self.MAX_FILE_SIZE:
            raise ValueError(f"File too large: {file.size} bytes")
        
        # Check MIME type
        if file_type == "image":
            if file.content_type not in self.ALLOWED_IMAGE_TYPES:
                raise ValueError(f"Invalid image type: {file.content_type}")
        elif file_type == "audio":
            if file.content_type not in self.ALLOWED_AUDIO_TYPES:
                raise ValueError(f"Invalid audio type: {file.content_type}")
        
        # Scan for malware
        is_safe = await self.scan_file(file)
        if not is_safe:
            raise ValueError("File failed security scan")
        
        # Validate image content
        if file_type == "image":
            await self.validate_image_content(file)
        
        return {
            "valid": True,
            "mime_type": file.content_type,
            "size": file.size
        }
    
    async def validate_image_content(self, file: UploadFile) -> None:
        """
        Check image for inappropriate content
        """
        # Use content moderation API
        image_data = await file.read()
        
        # Check for NSFW content
        moderation = await self.content_moderator.check_image(image_data)
        
        if moderation["nsfw_score"] > 0.8:
            raise ValueError("Image contains inappropriate content")
        
        # Check for deepfakes
        deepfake_check = await self.deepfake_detector.analyze(image_data)
        
        if deepfake_check["is_deepfake"]:
            raise ValueError("Image appears to be a deepfake")
```

### 2. Rate Limiting

```python
# backend/security/rate_limit.py

from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.util import get_remote_address

limiter = Limiter(key_func=get_remote_address)

@app.post("/api/generate")
@limiter.limit("5/minute")  # 5 requests per minute
@limiter.limit("50/hour")   # 50 requests per hour
async def generate_content(request: Request, ...):
    """
    Rate-limited generation endpoint
    """
    pass
```

### 3. Authentication & Authorization

```python
# backend/security/auth.py

from jose import JWTError, jwt
from passlib.context import CryptContext

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

class AuthManager:
    """
    Handle authentication and authorization
    """
    
    SECRET_KEY = os.getenv("SECRET_KEY")
    ALGORITHM = "HS256"
    ACCESS_TOKEN_EXPIRE = 60  # minutes
    
    def create_access_token(self, data: dict) -> str:
        """
        Create JWT token
        """
        to_encode = data.copy()
        expire = datetime.utcnow() + timedelta(minutes=self.ACCESS_TOKEN_EXPIRE)
        to_encode.update({"exp": expire})
        
        token = jwt.encode(to_encode, self.SECRET_KEY, algorithm=self.ALGORITHM)
        return token
    
    async def verify_token(self, token: str) -> Dict:
        """
        Verify and decode token
        """
        try:
            payload = jwt.decode(token, self.SECRET_KEY, algorithms=[self.ALGORITHM])
            return payload
        except JWTError:
            raise HTTPException(status_code=401, detail="Invalid token")
    
    def hash_password(self, password: str) -> str:
        """
        Hash password
        """
        return pwd_context.hash(password)
    
    def verify_password(self, plain: str, hashed: str) -> bool:
        """
        Verify password
        """
        return pwd_context.verify(plain, hashed)
```

### 4. Data Encryption

```python
# backend/security/encryption.py

from cryptography.fernet import Fernet

class DataEncryption:
    """
    Encrypt sensitive data
    """
    
    def __init__(self):
        self.key = os.getenv("ENCRYPTION_KEY").encode()
        self.cipher = Fernet(self.key)
    
    def encrypt(self, data: str) -> str:
        """
        Encrypt string data
        """
        encrypted = self.cipher.encrypt(data.encode())
        return encrypted.decode()
    
    def decrypt(self, encrypted_data: str) -> str:
        """
        Decrypt string data
        """
        decrypted = self.cipher.decrypt(encrypted_data.encode())
        return decrypted.decode()
    
    def encrypt_file(self, input_path: str, output_path: str) -> None:
        """
        Encrypt file
        """
        with open(input_path, 'rb') as f:
            data = f.read()
        
        encrypted = self.cipher.encrypt(data)
        
        with open(output_path, 'wb') as f:
            f.write(encrypted)
```

### 5. Content Moderation

```python
# backend/security/moderation.py

class ContentModerator:
    """
    Moderate user-generated content
    """
    
    async def check_image(self, image_data: bytes) -> Dict:
        """
        Check image for inappropriate content
        """
        # Use AWS Rekognition, Google Vision, or similar
        moderation_result = {
            "nsfw_score": 0.0,
            "violence_score": 0.0,
            "hate_symbols": False,
            "safe": True
        }
        
        # Analyze image
        analysis = await self._analyze_image(image_data)
        
        moderation_result.update(analysis)
        moderation_result["safe"] = (
            analysis["nsfw_score"] < 0.8 and
            analysis["violence_score"] < 0.8 and
            not analysis["hate_symbols"]
        )
        
        return moderation_result
    
    async def check_text(self, text: str) -> Dict:
        """
        Check text for inappropriate content
        """
        # Check for profanity, hate speech, etc.
        issues = []
        
        # Profanity filter
        if self._contains_profanity(text):
            issues.append("profanity")
        
        # Hate speech detection
        if await self._detect_hate_speech(text):
            issues.append("hate_speech")
        
        # Personal information
        if self._contains_pii(text):
            issues.append("personal_info")
        
        return {
            "safe": len(issues) == 0,
            "issues": issues
        }
```

## Compliance

### 1. GDPR Compliance

```python
# backend/compliance/gdpr.py

class GDPRCompliance:
    """
    Ensure GDPR compliance
    """
    
    async def handle_data_request(
        self,
        user_id: str,
        request_type: str
    ) -> Dict:
        """
        Handle GDPR data requests
        
        request_type: 'access', 'delete', 'export'
        """
        if request_type == "access":
            return await self._get_user_data(user_id)
        
        elif request_type == "delete":
            return await self._delete_user_data(user_id)
        
        elif request_type == "export":
            return await self._export_user_data(user_id)
    
    async def _get_user_data(self, user_id: str) -> Dict:
        """
        Get all user data
        """
        return {
            "profile": await self.db.get_profile(user_id),
            "generations": await self.db.get_generations(user_id),
            "usage": await self.db.get_usage(user_id),
            "transactions": await self.db.get_transactions(user_id)
        }
    
    async def _delete_user_data(self, user_id: str) -> Dict:
        """
        Delete all user data (right to be forgotten)
        """
        # Delete from database
        await self.db.delete_user(user_id)
        
        # Delete files
        await self.storage.delete_user_files(user_id)
        
        # Anonymize logs
        await self.logs.anonymize_user(user_id)
        
        return {
            "deleted": True,
            "timestamp": datetime.now().isoformat()
        }
    
    async def _export_user_data(self, user_id: str) -> str:
        """
        Export user data in machine-readable format
        """
        data = await self._get_user_data(user_id)
        
        # Create export file
        export_file = f"user_data_{user_id}.json"
        with open(export_file, 'w') as f:
            json.dump(data, f, indent=2)
        
        return export_file
```

### 2. Copyright Protection

```python
# backend/compliance/copyright.py

class CopyrightProtection:
    """
    Protect copyrighted content
    """
    
    async def check_music(self, audio_file: str) -> Dict:
        """
        Check if music is copyrighted
        """
        # Use audio fingerprinting (ACRCloud, Gracenote)
        fingerprint = await self._generate_fingerprint(audio_file)
        
        matches = await self._search_copyright_db(fingerprint)
        
        if matches:
            return {
                "copyrighted": True,
                "matches": matches,
                "action": "block"
            }
        
        return {
            "copyrighted": False,
            "safe_to_use": True
        }
    
    async def watermark_content(
        self,
        video_path: str,
        metadata: Dict
    ) -> str:
        """
        Add watermark to protect content
        """
        # Visible watermark
        watermarked = await self._add_visible_watermark(video_path)
        
        # Invisible fingerprint
        fingerprinted = await self._add_digital_fingerprint(
            watermarked,
            metadata
        )
        
        return fingerprinted
```

### 3. Data Retention

```python
# backend/compliance/retention.py

class DataRetention:
    """
    Manage data retention policies
    """
    
    RETENTION_POLICIES = {
        "uploads": 7,      # days
        "outputs": 30,     # days
        "analytics": 365,  # days
        "logs": 90        # days
    }
    
    async def cleanup_old_data(self) -> Dict:
        """
        Remove data past retention period
        """
        cleaned = {
            "uploads": 0,
            "outputs": 0,
            "logs": 0
        }
        
        # Clean uploads
        cutoff = datetime.now() - timedelta(days=self.RETENTION_POLICIES["uploads"])
        cleaned["uploads"] = await self._delete_old_files("uploads", cutoff)
        
        # Clean outputs
        cutoff = datetime.now() - timedelta(days=self.RETENTION_POLICIES["outputs"])
        cleaned["outputs"] = await self._delete_old_files("outputs", cutoff)
        
        # Clean logs
        cutoff = datetime.now() - timedelta(days=self.RETENTION_POLICIES["logs"])
        cleaned["logs"] = await self._delete_old_logs(cutoff)
        
        return cleaned
```

## Security Checklist

### Pre-Production
- [ ] All secrets in environment variables
- [ ] Database credentials encrypted
- [ ] API keys secured
- [ ] HTTPS enforced
- [ ] CORS properly configured
- [ ] Rate limiting enabled
- [ ] Input validation implemented
- [ ] File scanning active
- [ ] Content moderation enabled
- [ ] Error messages sanitized

### Post-Production
- [ ] Security audit completed
- [ ] Penetration testing done
- [ ] Vulnerability scan passed
- [ ] SSL certificate valid
- [ ] Backup system tested
- [ ] Incident response plan ready
- [ ] Monitoring alerts configured
- [ ] Log aggregation working

## Incident Response Plan

### 1. Detection
- Monitor security alerts
- Review error logs
- Track unusual activity

### 2. Assessment
- Identify breach type
- Determine scope
- Assess impact

### 3. Containment
- Isolate affected systems
- Block malicious IPs
- Revoke compromised credentials

### 4. Remediation
- Patch vulnerabilities
- Update security measures
- Restore from backups if needed

### 5. Notification
- Notify affected users
- Report to authorities (if required)
- Update security documentation

### 6. Review
- Post-mortem analysis
- Update procedures
- Implement improvements

---

**Security is ongoing. Review and update regularly.**
