# LUMATU TESTING STRATEGY

## Testing Philosophy

**Test Pyramid:**
```
        /\
       /  \     E2E Tests (10%)
      /____\
     /      \   Integration Tests (30%)
    /________\
   /          \ Unit Tests (60%)
  /____________\
```

---

## Unit Tests

### Backend Unit Tests

**Location:** `backend/tests/test_*.py`

#### Identity Validator Tests
```python
# backend/tests/test_identity.py

import pytest
from services.identity import IdentityValidator

class TestIdentityValidator:
    
    @pytest.fixture
    def validator(self):
        return IdentityValidator()
    
    @pytest.mark.asyncio
    async def test_validate_high_quality_image(self, validator):
        """Test validation with high-quality image"""
        result = await validator.validate("tests/fixtures/avatar_hq.jpg")
        
        assert result["valid"] == True
        assert result["quality_score"] >= 0.8
        assert "avatar_id" in result
        assert "features" in result
    
    @pytest.mark.asyncio
    async def test_validate_low_quality_image(self, validator):
        """Test validation with low-quality image"""
        result = await validator.validate("tests/fixtures/avatar_lq.jpg")
        
        assert result["quality_score"] < 0.8
    
    @pytest.mark.asyncio
    async def test_consistency_check_high_similarity(self, validator):
        """Test consistency with similar images"""
        result = await validator.check_consistency(
            "tests/fixtures/reference.jpg",
            "tests/fixtures/generated_similar.jpg"
        )
        
        assert result["score"] >= 0.85
        assert result["passed"] == True
    
    @pytest.mark.asyncio
    async def test_consistency_check_low_similarity(self, validator):
        """Test consistency with different images"""
        result = await validator.check_consistency(
            "tests/fixtures/reference.jpg",
            "tests/fixtures/generated_different.jpg"
        )
        
        assert result["score"] < 0.85
        assert result["passed"] == False
        assert result["drift_detected"] == True
```

#### Viral Score Tests
```python
# backend/tests/test_viral_score.py

import pytest
from services.viral import ViralScoreEngine

class TestViralScoreEngine:
    
    @pytest.fixture
    def engine(self):
        return ViralScoreEngine()
    
    @pytest.mark.asyncio
    async def test_high_viral_score(self, engine):
        """Test calculation with optimized video"""
        video_data = {
            "hook_enhanced": True,
            "rhythm_optimized": True,
            "captions_enabled": True,
            "frames": [{"duration": 5}] * 12,
            "effects": [
                {"type": "zoom"},
                {"type": "overlay"}
            ]
        }
        
        result = await engine.calculate(video_data)
        
        assert result["viral_score"] >= 0.75
        assert result["recommendation"] == "VIRAL_READY"
    
    @pytest.mark.asyncio
    async def test_low_viral_score(self, engine):
        """Test calculation with basic video"""
        video_data = {
            "frames": [{"duration": 5}] * 12
        }
        
        result = await engine.calculate(video_data)
        
        assert result["viral_score"] < 0.75
        assert result["action"] in ["optimize", "block"]
    
    def test_score_weights_sum_to_one(self, engine):
        """Ensure score weights are properly balanced"""
        total = sum(engine.weights.values())
        assert abs(total - 1.0) < 0.001
```

#### Script Writer Tests
```python
# backend/tests/test_script_writer.py

import pytest
from orchestrator.agents.script_writer import ScriptWriterAgent

class TestScriptWriter:
    
    @pytest.fixture
    def writer(self):
        return ScriptWriterAgent()
    
    @pytest.mark.asyncio
    async def test_reality_script_generation(self, writer):
        """Test reality show script generation"""
        script = await writer.generate_script("reality", {})
        
        assert script["mode"] == "reality"
        assert len(script["scenes"]) > 0
        assert script["total_duration"] > 0
        assert "narrative_arc" in script
        
        # Check scene structure
        for scene in script["scenes"]:
            assert "id" in scene
            assert "start" in scene
            assert "end" in scene
            assert "description" in scene
            assert "emotion" in scene
    
    @pytest.mark.asyncio
    async def test_terror_script_has_escalation(self, writer):
        """Test terror scripts have proper escalation"""
        script = await writer.generate_script("terror", {})
        
        # Check intensity increases
        intensities = [s["intensity"] for s in script["scenes"]]
        max_intensity = max(intensities)
        
        assert max_intensity >= 0.9  # Should have high peak
        assert intensities[0] < intensities[-2]  # Escalation
    
    def test_frame_splitting_accuracy(self, writer):
        """Test accurate frame splitting"""
        scenes = [
            {"id": 1, "start": 0, "end": 5, "description": "test", 
             "emotion": "test", "intensity": 0.5}
        ]
        
        frames = writer.split_into_frames(scenes, fps=30)
        
        assert len(frames) == 150  # 5 seconds * 30 fps
        assert frames[0]["timestamp"] == 0
        assert frames[-1]["timestamp"] < 5
```

### Frontend Unit Tests

**Location:** `frontend/__tests__/`

#### Component Tests
```typescript
// frontend/__tests__/AvatarUpload.test.tsx

import { render, screen, fireEvent } from '@testing-library/react'
import AvatarUpload from '@/app/avatar/components/AvatarUpload'

describe('AvatarUpload', () => {
  it('renders upload button when no avatar', () => {
    render(<AvatarUpload avatar={null} onUpload={() => {}} />)
    
    expect(screen.getByText(/click to upload avatar/i)).toBeInTheDocument()
  })
  
  it('shows preview when avatar uploaded', () => {
    const file = new File(['avatar'], 'avatar.jpg', { type: 'image/jpeg' })
    
    render(<AvatarUpload avatar={file} onUpload={() => {}} />)
    
    expect(screen.getByAltText(/avatar preview/i)).toBeInTheDocument()
  })
  
  it('calls onUpload when file selected', () => {
    const onUpload = jest.fn()
    render(<AvatarUpload avatar={null} onUpload={onUpload} />)
    
    const input = screen.getByRole('button')
    const file = new File(['avatar'], 'avatar.jpg', { type: 'image/jpeg' })
    
    fireEvent.change(input, { target: { files: [file] } })
    
    expect(onUpload).toHaveBeenCalledWith(file)
  })
})
```

#### Hook Tests
```typescript
// frontend/__tests__/useWebSocket.test.tsx

import { renderHook, waitFor } from '@testing-library/react'
import { useWebSocket } from '@/app/avatar/hooks/useWebSocket'

describe('useWebSocket', () => {
  it('connects when active', async () => {
    const { result } = renderHook(() => useWebSocket(true))
    
    await waitFor(() => {
      expect(result.current.status).toBeDefined()
    })
  })
  
  it('updates status on pipeline events', async () => {
    const { result } = renderHook(() => useWebSocket(true))
    
    // Simulate server event
    mockSocket.emit('pipeline_update', { stage: 'Identity Validation', progress: 10 })
    
    await waitFor(() => {
      expect(result.current.status).toBe('Identity Validation')
    })
  })
})
```

---

## Integration Tests

### API Integration Tests

```python
# backend/tests/test_api_integration.py

import pytest
from fastapi.testclient import TestClient
from main import app

client = TestClient(app)

class TestAPIIntegration:
    
    def test_health_check(self):
        """Test health endpoint"""
        response = client.get("/health")
        
        assert response.status_code == 200
        assert response.json()["status"] == "healthy"
    
    def test_generate_endpoint_requires_avatar(self):
        """Test generate endpoint validation"""
        response = client.post("/api/generate", data={"mode": "reality"})
        
        assert response.status_code == 422  # Validation error
    
    def test_generate_endpoint_success(self):
        """Test successful generation request"""
        with open("tests/fixtures/avatar.jpg", "rb") as avatar:
            response = client.post(
                "/api/generate",
                files={"avatar": avatar},
                data={"mode": "reality"}
            )
        
        assert response.status_code == 200
        data = response.json()
        assert data["success"] == True
        assert "session_id" in data
    
    def test_generate_endpoint_invalid_mode(self):
        """Test invalid mode rejection"""
        with open("tests/fixtures/avatar.jpg", "rb") as avatar:
            response = client.post(
                "/api/generate",
                files={"avatar": avatar},
                data={"mode": "invalid"}
            )
        
        assert response.status_code == 422
```

### Pipeline Integration Tests

```python
# backend/tests/test_pipeline_integration.py

import pytest
from orchestrator.pipeline import GenerationPipeline
from orchestrator.brain import AvatarBrain

class TestPipelineIntegration:
    
    @pytest.fixture
    async def pipeline(self):
        brain = AvatarBrain()
        # Mock socketio
        sio = MockSocketIO()
        return GenerationPipeline(brain, sio)
    
    @pytest.mark.asyncio
    async def test_full_pipeline_execution(self, pipeline):
        """Test complete pipeline flow"""
        request_data = {
            "session_id": "test_123",
            "avatar_path": "tests/fixtures/avatar.jpg",
            "mode": "reality",
            "voice_path": None,
            "music_path": None
        }
        
        # Execute pipeline
        await pipeline.execute(request_data)
        
        # Verify stages were called
        assert pipeline.sio.events_emitted > 0
        
        # Check output exists
        output_dir = Path(f"outputs/{request_data['session_id']}")
        assert output_dir.exists()
    
    @pytest.mark.asyncio
    async def test_pipeline_handles_low_viral_score(self, pipeline):
        """Test pipeline optimization for low scores"""
        # Mock low viral score
        pipeline.viral_engine.calculate = lambda x: 0.55
        
        request_data = {
            "session_id": "test_456",
            "avatar_path": "tests/fixtures/avatar.jpg",
            "mode": "reality"
        }
        
        await pipeline.execute(request_data)
        
        # Should trigger optimization
        assert pipeline.optimization_triggered == True
```

---

## End-to-End Tests

### Selenium/Playwright Tests

```python
# backend/tests/test_e2e.py

import pytest
from playwright.sync_api import Page, expect

class TestE2E:
    
    def test_complete_user_flow(self, page: Page):
        """Test complete user journey"""
        # Navigate to app
        page.goto("http://localhost:3000")
        
        # Upload avatar
        page.set_input_files("input[type='file'][accept='image/*']", 
                            "tests/fixtures/avatar.jpg")
        
        # Wait for preview
        expect(page.locator("img[alt='Avatar preview']")).to_be_visible()
        
        # Select mode
        page.click("button:has-text('Reality Show')")
        
        # Click generate
        page.click("button:has-text('Generate')")
        
        # Wait for pipeline to start
        expect(page.locator("text=Generation Pipeline")).to_be_visible()
        
        # Wait for completion (with timeout)
        expect(page.locator("text=Complete!")).to_be_visible(timeout=300000)
        
        # Check viral score displayed
        expect(page.locator("text=/Viral Score/")).to_be_visible()
        
        # Check download button
        expect(page.locator("button:has-text('Download')")).to_be_visible()
    
    def test_music_video_requires_music(self, page: Page):
        """Test music video validation"""
        page.goto("http://localhost:3000")
        
        # Upload avatar
        page.set_input_files("input[type='file'][accept='image/*']", 
                            "tests/fixtures/avatar.jpg")
        
        # Select music video mode
        page.click("button:has-text('Music Video')")
        
        # Try to generate without music
        page.click("button:has-text('Generate')")
        
        # Should show music upload
        expect(page.locator("text=Upload music")).to_be_visible()
        expect(page.locator("button:has-text('Generate')")).to_be_disabled()
```

---

## Performance Tests

### Load Testing

```python
# backend/tests/test_performance.py

import pytest
import asyncio
from locust import HttpUser, task, between

class LUMATUUser(HttpUser):
    wait_time = between(1, 3)
    
    @task
    def health_check(self):
        self.client.get("/health")
    
    @task(3)
    def generate_content(self):
        with open("tests/fixtures/avatar.jpg", "rb") as avatar:
            self.client.post(
                "/api/generate",
                files={"avatar": avatar},
                data={"mode": "reality"}
            )

# Run with: locust -f test_performance.py --host=http://localhost:8000
```

### Benchmark Tests

```python
# backend/tests/test_benchmarks.py

import pytest
import time
from services.viral import ViralScoreEngine

class TestBenchmarks:
    
    def test_viral_score_calculation_speed(self):
        """Viral score should calculate in <200ms"""
        engine = ViralScoreEngine()
        video_data = {"frames": [{"duration": 5}] * 12}
        
        start = time.time()
        score = asyncio.run(engine.calculate(video_data))
        duration = time.time() - start
        
        assert duration < 0.2  # 200ms
    
    def test_identity_validation_speed(self):
        """Identity validation should complete in <500ms"""
        validator = IdentityValidator()
        
        start = time.time()
        result = asyncio.run(validator.validate("tests/fixtures/avatar.jpg"))
        duration = time.time() - start
        
        assert duration < 0.5  # 500ms
```

---

## Test Fixtures

### Backend Fixtures

```python
# backend/tests/conftest.py

import pytest
from pathlib import Path

@pytest.fixture
def test_avatar():
    """Provide test avatar image"""
    return Path("tests/fixtures/avatar.jpg")

@pytest.fixture
def test_voice():
    """Provide test voice reference"""
    return Path("tests/fixtures/voice.mp3")

@pytest.fixture
def test_music():
    """Provide test music file"""
    return Path("tests/fixtures/music.mp3")

@pytest.fixture
def mock_video_data():
    """Provide mock video data"""
    return {
        "frames": [
            {"id": i, "duration": 5, "timestamp": i * 5}
            for i in range(12)
        ],
        "duration": 60,
        "fps": 30
    }

@pytest.fixture
def mock_script():
    """Provide mock script"""
    return {
        "mode": "reality",
        "scenes": [
            {
                "id": 1,
                "start": 0,
                "end": 15,
                "description": "Opening scene",
                "emotion": "intrigue",
                "intensity": 0.6
            },
            {
                "id": 2,
                "start": 15,
                "end": 45,
                "description": "Peak drama",
                "emotion": "climax",
                "intensity": 0.95
            }
        ]
    }
```

---

## Test Coverage Goals

### Minimum Coverage
- Unit tests: 80% coverage
- Integration tests: 70% coverage
- E2E tests: Critical paths

### Coverage Report
```bash
# Generate coverage report
cd backend
pytest --cov=. --cov-report=html tests/

# View report
open htmlcov/index.html
```

---

## Continuous Testing

### GitHub Actions Workflow

```yaml
# .github/workflows/test.yml

name: Test Suite

on: [push, pull_request]

jobs:
  test:
    runs-on: ubuntu-latest
    
    steps:
    - uses: actions/checkout@v3
    
    - name: Set up Python
      uses: actions/setup-python@v4
      with:
        python-version: '3.10'
    
    - name: Install dependencies
      run: |
        cd backend
        pip install -r requirements.txt
        pip install pytest pytest-cov pytest-asyncio
    
    - name: Run tests
      run: |
        cd backend
        pytest --cov=. --cov-report=xml tests/
    
    - name: Upload coverage
      uses: codecov/codecov-action@v3
      with:
        file: ./backend/coverage.xml
```

---

## Testing Checklist

### Pre-Commit
- [ ] All unit tests pass
- [ ] Code coverage >80%
- [ ] Linting passes
- [ ] Type checks pass

### Pre-Deploy
- [ ] Integration tests pass
- [ ] E2E tests pass
- [ ] Performance benchmarks met
- [ ] Security scan clean

### Post-Deploy
- [ ] Smoke tests pass
- [ ] Health check responds
- [ ] Monitoring active
- [ ] Error rate normal

---

## Test Maintenance

### Regular Reviews
- Monthly test suite review
- Quarterly coverage analysis
- Remove obsolete tests
- Add tests for new features

### Best Practices
- Test names describe behavior
- One assertion per test (when possible)
- Use fixtures for common setup
- Mock external dependencies
- Test edge cases

---

**Comprehensive testing ensures LUMATU remains reliable and production-ready.**
