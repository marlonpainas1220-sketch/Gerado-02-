#!/usr/bin/env python3
"""
LUMATU CLI Tool
Manage avatar generations, view analytics, and configure system
"""

import argparse
import json
import sys
from pathlib import Path
from typing import Dict, Any

from services.analytics import PerformanceMonitor, ViralAnalytics
from config import (
    VIRAL_THRESHOLDS,
    ENGINE_CONFIG,
    EMOTIONAL_ARC_CONFIG
)


class LUMATUCLI:
    """Command-line interface for LUMATU"""
    
    def __init__(self):
        self.monitor = PerformanceMonitor()
        self.analytics = ViralAnalytics()
    
    def show_analytics(self, detailed: bool = False) -> None:
        """Display system analytics"""
        analytics = self.monitor.get_analytics()
        
        if not analytics:
            print("No analytics data available yet.")
            return
        
        print("=" * 60)
        print("LUMATU ANALYTICS")
        print("=" * 60)
        print(f"\nTotal Sessions: {analytics['total_sessions']}")
        print(f"Success Rate: {analytics['success_rate']:.1%}")
        print(f"Average Viral Score: {analytics['average_viral_score']:.2f}")
        print(f"High Viral Rate (≥0.75): {analytics['high_viral_rate']:.1%}")
        print(f"Average Duration: {analytics['average_duration']:.1f}s")
        
        print("\nMode Distribution:")
        for mode, count in analytics['mode_distribution'].items():
            print(f"  {mode}: {count}")
        
        if detailed:
            print("\nStage Performance (avg duration):")
            for stage, duration in analytics['stage_performance'].items():
                print(f"  {stage}: {duration:.2f}s")
        
        print("=" * 60)
    
    def show_viral_patterns(self) -> None:
        """Display viral content patterns"""
        patterns = self.analytics.analyze_viral_patterns()
        
        if not patterns:
            print("Not enough data to analyze patterns.")
            return
        
        print("=" * 60)
        print("VIRAL PATTERNS ANALYSIS")
        print("=" * 60)
        
        viral = patterns['viral_characteristics']
        low = patterns['low_viral_characteristics']
        
        print("\nViral Content Characteristics:")
        print(f"  Avg Identity Consistency: {viral.get('avg_identity_consistency', 0):.2f}")
        print(f"  Avg Hook Power: {viral.get('avg_hook_power', 0):.2f}")
        
        print("\nLow Viral Content Characteristics:")
        print(f"  Avg Identity Consistency: {low.get('avg_identity_consistency', 0):.2f}")
        print(f"  Avg Hook Power: {low.get('avg_hook_power', 0):.2f}")
        
        print("\nSuccess Factors:")
        for factor in patterns['success_factors']:
            print(f"  • {factor}")
        
        print("=" * 60)
    
    def show_config(self) -> None:
        """Display current configuration"""
        print("=" * 60)
        print("LUMATU CONFIGURATION")
        print("=" * 60)
        
        print("\nViral Thresholds:")
        for key, value in VIRAL_THRESHOLDS.items():
            print(f"  {key}: {value}")
        
        print("\nVideo Engines:")
        for mode, config in ENGINE_CONFIG.items():
            print(f"  {mode}: {config['primary']} (fallback: {config['fallback']})")
        
        print("\nEmotional Arc Configs:")
        for arc_type, config in EMOTIONAL_ARC_CONFIG.items():
            print(f"  {arc_type}: {config['peaks']} peaks")
        
        print("=" * 60)
    
    def list_sessions(self, limit: int = 10) -> None:
        """List recent sessions"""
        metrics_file = Path("metrics.jsonl")
        
        if not metrics_file.exists():
            print("No sessions found.")
            return
        
        sessions = []
        with metrics_file.open("r") as f:
            for line in f:
                sessions.append(json.loads(line))
        
        # Get most recent
        sessions = sorted(
            sessions,
            key=lambda x: x.get('start_time', ''),
            reverse=True
        )[:limit]
        
        print("=" * 60)
        print(f"RECENT SESSIONS (last {limit})")
        print("=" * 60)
        
        for session in sessions:
            session_id = session['session_id']
            mode = session.get('request', {}).get('mode', 'unknown')
            viral_score = session.get('viral_score', 0)
            duration = session.get('total_duration', 0)
            errors = len(session.get('errors', []))
            
            status = "✓" if errors == 0 else "✗"
            
            print(f"\n{status} {session_id}")
            print(f"  Mode: {mode}")
            print(f"  Viral Score: {viral_score:.2f}")
            print(f"  Duration: {duration:.1f}s")
            if errors > 0:
                print(f"  Errors: {errors}")
        
        print("=" * 60)
    
    def export_report(self, output_file: str) -> None:
        """Export analytics report"""
        self.monitor.export_report(output_file)
        print(f"Report exported to {output_file}")
    
    def test_config(self) -> None:
        """Test configuration validity"""
        print("Testing LUMATU configuration...")
        
        issues = []
        
        # Check thresholds
        if VIRAL_THRESHOLDS['viral_ready'] <= VIRAL_THRESHOLDS['needs_adjustment']:
            issues.append("Viral threshold must be higher than adjustment threshold")
        
        # Check engine configs
        for mode, config in ENGINE_CONFIG.items():
            if config['primary'] not in ['runway', 'pika', 'luma']:
                issues.append(f"Invalid primary engine for {mode}: {config['primary']}")
        
        if issues:
            print("Configuration Issues:")
            for issue in issues:
                print(f"  ✗ {issue}")
        else:
            print("✓ Configuration is valid")


def main():
    parser = argparse.ArgumentParser(
        description="LUMATU CLI - Manage avatar content generation"
    )
    
    subparsers = parser.add_subparsers(dest='command', help='Commands')
    
    # Analytics command
    analytics_parser = subparsers.add_parser('analytics', help='Show analytics')
    analytics_parser.add_argument(
        '--detailed',
        action='store_true',
        help='Show detailed analytics'
    )
    
    # Patterns command
    subparsers.add_parser('patterns', help='Show viral patterns')
    
    # Config command
    subparsers.add_parser('config', help='Show configuration')
    
    # Sessions command
    sessions_parser = subparsers.add_parser('sessions', help='List sessions')
    sessions_parser.add_argument(
        '--limit',
        type=int,
        default=10,
        help='Number of sessions to show'
    )
    
    # Export command
    export_parser = subparsers.add_parser('export', help='Export report')
    export_parser.add_argument(
        '--output',
        default='report.json',
        help='Output file path'
    )
    
    # Test command
    subparsers.add_parser('test', help='Test configuration')
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        return
    
    cli = LUMATUCLI()
    
    if args.command == 'analytics':
        cli.show_analytics(detailed=args.detailed)
    elif args.command == 'patterns':
        cli.show_viral_patterns()
    elif args.command == 'config':
        cli.show_config()
    elif args.command == 'sessions':
        cli.list_sessions(limit=args.limit)
    elif args.command == 'export':
        cli.export_report(output_file=args.output)
    elif args.command == 'test':
        cli.test_config()


if __name__ == '__main__':
    main()
