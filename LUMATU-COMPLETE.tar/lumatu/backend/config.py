"""
LUMATU Advanced Configuration
Customize viral thresholds, engine preferences, and agent behavior
"""

# VIRAL SCORE CONFIGURATION
VIRAL_THRESHOLDS = {
    "viral_ready": 0.75,      # Auto-publish
    "needs_adjustment": 0.60,  # Auto-optimize
    "blocked": 0.00           # Reject
}

VIRAL_WEIGHTS = {
    "hook_power": 0.25,
    "emotion_density": 0.20,
    "identity_clarity": 0.15,
    "meme_timing": 0.15,
    "rhythm": 0.15,
    "novelty": 0.10
}

# IDENTITY VALIDATION
IDENTITY_CONFIG = {
    "consistency_threshold": 0.85,  # Min face match score
    "quality_threshold": 0.80,      # Min image quality
    "max_drift": 0.15,              # Max cumulative drift
    "strict_mode": True             # Regenerate on drift
}

# VIDEO ENGINE PREFERENCES
ENGINE_CONFIG = {
    "reality": {
        "primary": "runway",
        "fallback": "pika",
        "quality": "cinematic",
        "fps": 30,
        "resolution": "1080x1920"
    },
    "novela": {
        "primary": "runway",
        "fallback": "luma",
        "quality": "dramatic",
        "fps": 30,
        "resolution": "1080x1920"
    },
    "terror": {
        "primary": "pika",
        "fallback": "runway",
        "quality": "experimental",
        "fps": 24,
        "resolution": "1080x1920"
    },
    "music-video": {
        "primary": "luma",
        "fallback": "runway",
        "quality": "lip_sync",
        "fps": 30,
        "resolution": "1080x1920"
    }
}

# EMOTIONAL ARC SETTINGS
EMOTIONAL_ARC_CONFIG = {
    "30-day": {
        "peaks": 4,
        "intensity_multiplier": 1.0,
        "narrator_frequency": 3
    },
    "60-day": {
        "peaks": 8,
        "intensity_multiplier": 1.1,
        "narrator_frequency": 3
    },
    "90-day": {
        "peaks": 3,
        "intensity_multiplier": 1.2,
        "narrator_frequency": 4
    }
}

# NARRATOR SETTINGS
NARRATOR_CONFIG = {
    "enabled": True,
    "style": "sarcastic",
    "max_duration_per_line": 3.0,  # seconds
    "trigger_points": ["cold_open", "peak_tension", "cliffhanger"],
    "voice_synthesis": "elevenlabs",  # or "poe_voice"
}

# MEME INJECTION
MEME_CONFIG = {
    "enabled": True,
    "max_memes_per_video": 5,
    "types": [
        "dramatic_zoom",
        "record_scratch",
        "to_be_continued",
        "glitch_effect",
        "freeze_frame"
    ],
    "timing_precision": 0.5  # seconds
}

# EDITING PARAMETERS
EDITING_CONFIG = {
    "dynamic_captions": True,
    "caption_style": "impact",
    "transition_types": ["hard_cut", "crossfade", "fade"],
    "color_grading": True,
    "audio_normalization": True,
    "compression": "h264"
}

# POE BOT MAPPING
POE_BOTS = {
    "script_writer": "claude-sonnet-4-5",
    "emotion_architect": "claude-sonnet-4-5",
    "frame_planner": "claude-sonnet-4-5",
    "narrator": "claude-sonnet-4-5",
    "culture_memes": "claude-sonnet-4-5",
    "viral_predictor": "claude-sonnet-4-5"
}

# API RATE LIMITS
RATE_LIMITS = {
    "runway": {
        "requests_per_minute": 10,
        "concurrent": 3
    },
    "pika": {
        "requests_per_minute": 8,
        "concurrent": 2
    },
    "luma": {
        "requests_per_minute": 12,
        "concurrent": 4
    }
}

# OPTIMIZATION STRATEGIES
AUTO_OPTIMIZATION = {
    "enabled": True,
    "strategies": {
        "weak_hook": ["enhance_opening", "add_pattern_interrupt"],
        "low_emotion": ["increase_tension_variance", "add_peaks"],
        "identity_drift": ["strict_regeneration", "apply_corrections"],
        "poor_rhythm": ["optimize_pacing", "dynamic_cuts"],
        "low_meme_score": ["inject_more_memes", "improve_timing"]
    },
    "max_iterations": 2
}

# STORAGE SETTINGS
STORAGE_CONFIG = {
    "upload_max_size_mb": 50,
    "cleanup_after_days": 7,
    "archive_finals": True,
    "backup_enabled": False
}

# MONITORING
MONITORING_CONFIG = {
    "log_level": "INFO",
    "track_metrics": True,
    "alert_on_low_viral": True,
    "export_analytics": True
}
