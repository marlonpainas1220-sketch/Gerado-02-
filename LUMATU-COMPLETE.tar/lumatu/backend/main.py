from fastapi import FastAPI, File, UploadFile, Form, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
import socketio
import asyncio
from pathlib import Path
import shutil
from datetime import datetime

from orchestrator.brain import AvatarBrain
from orchestrator.pipeline import GenerationPipeline

app = FastAPI(title="LUMATU API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

sio = socketio.AsyncServer(
    async_mode='asgi',
    cors_allowed_origins='*'
)
socket_app = socketio.ASGIApp(sio, app)

UPLOAD_DIR = Path("uploads")
OUTPUT_DIR = Path("outputs")
UPLOAD_DIR.mkdir(exist_ok=True)
OUTPUT_DIR.mkdir(exist_ok=True)

brain = AvatarBrain()
pipeline = GenerationPipeline(brain, sio)


@app.get("/")
async def root():
    return {"status": "LUMATU API Running"}


@app.post("/api/generate")
async def generate_content(
    background_tasks: BackgroundTasks,
    avatar: UploadFile = File(...),
    mode: str = Form(...),
    voice: UploadFile = File(None),
    music: UploadFile = File(None),
):
    session_id = datetime.now().strftime("%Y%m%d_%H%M%S")
    session_dir = UPLOAD_DIR / session_id
    session_dir.mkdir(exist_ok=True)
    
    avatar_path = session_dir / f"avatar_{avatar.filename}"
    with avatar_path.open("wb") as f:
        shutil.copyfileobj(avatar.file, f)
    
    voice_path = None
    if voice:
        voice_path = session_dir / f"voice_{voice.filename}"
        with voice_path.open("wb") as f:
            shutil.copyfileobj(voice.file, f)
    
    music_path = None
    if music:
        music_path = session_dir / f"music_{music.filename}"
        with music_path.open("wb") as f:
            shutil.copyfileobj(music.file, f)
    
    request_data = {
        "session_id": session_id,
        "avatar_path": str(avatar_path),
        "voice_path": str(voice_path) if voice_path else None,
        "music_path": str(music_path) if music_path else None,
        "mode": mode,
    }
    
    background_tasks.add_task(pipeline.execute, request_data)
    
    return JSONResponse({
        "success": True,
        "session_id": session_id,
        "message": "Generation started"
    })


@sio.event
async def connect(sid, environ):
    print(f"Client connected: {sid}")


@sio.event
async def disconnect(sid):
    print(f"Client disconnected: {sid}")


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(socket_app, host="0.0.0.0", port=8000)
