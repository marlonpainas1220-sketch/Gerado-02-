from typing import Dict, List, Any
import asyncio
import re


class CultureMemesAgent:
    """
    Agent responsible for detecting and injecting culturally relevant memes
    """
    
    def __init__(self):
        self.meme_database = self._initialize_meme_database()
        self.trending_formats = []
        self.catchphrase_patterns = self._initialize_catchphrase_patterns()
    
    def _initialize_meme_database(self) -> Dict[str, Dict]:
        """
        Database of meme formats and their triggers
        """
        return {
            "record_scratch": {
                "trigger_emotions": ["shock", "revelation", "plot_twist"],
                "trigger_phrases": ["wait", "hold on", "but then"],
                "audio": "record_scratch.mp3",
                "duration": 0.8,
                "freeze_frame": True,
                "narrator_line": "Yep, that's me. You're probably wondering..."
            },
            "dramatic_zoom": {
                "trigger_emotions": ["realization", "shock", "horror"],
                "trigger_phrases": ["realize", "see", "discover"],
                "effect": "zoom_in_fast",
                "intensity": 2.0,
                "duration": 1.5,
                "sound": "dun_dun_dun.wav"
            },
            "to_be_continued": {
                "trigger_emotions": ["cliffhanger", "anticipation"],
                "trigger_phrases": ["next time", "what happens", "find out"],
                "overlay": "to_be_continued_jojo.png",
                "music": "roundabout_yes.mp3",
                "position": "end",
                "duration": 3.0
            },
            "glitch_effect": {
                "trigger_emotions": ["confusion", "disorientation", "unreality"],
                "trigger_phrases": ["confused", "what", "doesn't make sense"],
                "effect": "digital_glitch",
                "intensity": 0.7,
                "duration": 0.5
            },
            "zoom_enhance": {
                "trigger_emotions": ["focus", "detail"],
                "trigger_phrases": ["look closer", "zoom in", "enhance"],
                "effect": "zoom_pixelate",
                "sound": "csi_enhance.wav",
                "duration": 2.0
            },
            "surprised_pikachu": {
                "trigger_emotions": ["shock", "surprise"],
                "trigger_phrases": ["can't believe", "no way", "shocked"],
                "overlay": "surprised_pikachu.png",
                "position": "corner",
                "duration": 1.5
            },
            "vine_boom": {
                "trigger_emotions": ["emphasis", "punchline"],
                "trigger_phrases": ["boom", "drop", "reveal"],
                "sound": "vine_boom.mp3",
                "visual_shake": True,
                "duration": 0.5
            },
            "spongebob_narrator": {
                "trigger_emotions": ["transition", "time_skip"],
                "trigger_phrases": ["later", "meanwhile", "the next day"],
                "card": "spongebob_time_card.png",
                "narrator": True,
                "duration": 2.0
            },
            "bruh_sound": {
                "trigger_emotions": ["disappointment", "cringe"],
                "trigger_phrases": ["really", "seriously", "bruh"],
                "sound": "bruh.mp3",
                "duration": 1.0
            },
            "sad_violin": {
                "trigger_emotions": ["sadness", "defeat"],
                "trigger_phrases": ["sad", "unfortunately", "failed"],
                "music": "sad_violin.mp3",
                "volume": 0.6,
                "duration": 3.0
            }
        }
    
    def _initialize_catchphrase_patterns(self) -> List[Dict]:
        """
        Patterns for detecting viral catchphrases
        """
        return [
            {
                "pattern": r"(?i)(not gonna lie|ngl)",
                "meme": "ngl_emphasis",
                "highlight": True
            },
            {
                "pattern": r"(?i)(literally|actual)",
                "meme": "literally_zoom",
                "zoom": True
            },
            {
                "pattern": r"(?i)(wait for it)",
                "meme": "dramatic_pause",
                "pause": 1.5
            },
            {
                "pattern": r"(?i)(plot twist|twist)",
                "meme": "record_scratch",
                "freeze": True
            },
            {
                "pattern": r"(?i)(iconic|legendary)",
                "meme": "sparkle_effect",
                "effect": "sparkles"
            }
        ]
    
    async def analyze_script(self, script: Dict, emotional_arc: Dict) -> List[Dict]:
        """
        Analyze script for meme injection opportunities
        """
        opportunities = []
        scenes = script.get("scenes", [])
        
        for scene in scenes:
            # Emotion-based triggers
            emotion_memes = await self._detect_emotion_memes(scene)
            opportunities.extend(emotion_memes)
            
            # Dialogue-based triggers
            if "dialogue" in scene:
                dialogue_memes = await self._detect_dialogue_memes(scene)
                opportunities.extend(dialogue_memes)
            
            # Timing-based triggers
            timing_memes = await self._detect_timing_memes(scene, emotional_arc)
            opportunities.extend(timing_memes)
        
        # Remove duplicates and sort by timestamp
        opportunities = self._deduplicate_memes(opportunities)
        opportunities.sort(key=lambda x: x["timestamp"])
        
        # Limit to max memes
        max_memes = 5
        if len(opportunities) > max_memes:
            opportunities = self._select_best_memes(opportunities, max_memes)
        
        return opportunities
    
    async def _detect_emotion_memes(self, scene: Dict) -> List[Dict]:
        """
        Detect meme opportunities based on emotions
        """
        memes = []
        emotion = scene.get("emotion", "")
        timestamp = (scene["start"] + scene["end"]) / 2
        
        for meme_id, meme_data in self.meme_database.items():
            if emotion in meme_data.get("trigger_emotions", []):
                memes.append({
                    "timestamp": timestamp,
                    "meme_id": meme_id,
                    "meme_data": meme_data,
                    "trigger_type": "emotion",
                    "scene_id": scene["id"],
                    "confidence": 0.8
                })
        
        return memes
    
    async def _detect_dialogue_memes(self, scene: Dict) -> List[Dict]:
        """
        Detect meme opportunities in dialogue
        """
        memes = []
        dialogue = scene.get("dialogue", "").lower()
        timestamp = scene["start"]
        
        # Check meme database phrases
        for meme_id, meme_data in self.meme_database.items():
            trigger_phrases = meme_data.get("trigger_phrases", [])
            for phrase in trigger_phrases:
                if phrase in dialogue:
                    memes.append({
                        "timestamp": timestamp,
                        "meme_id": meme_id,
                        "meme_data": meme_data,
                        "trigger_type": "dialogue",
                        "scene_id": scene["id"],
                        "confidence": 0.9
                    })
        
        # Check catchphrase patterns
        for pattern_data in self.catchphrase_patterns:
            if re.search(pattern_data["pattern"], dialogue):
                memes.append({
                    "timestamp": timestamp,
                    "meme_id": pattern_data["meme"],
                    "meme_data": pattern_data,
                    "trigger_type": "catchphrase",
                    "scene_id": scene["id"],
                    "confidence": 0.85
                })
        
        return memes
    
    async def _detect_timing_memes(self, scene: Dict, arc: Dict) -> List[Dict]:
        """
        Detect meme opportunities based on timing
        """
        memes = []
        
        # End-of-video cliffhanger
        if scene.get("emotion") == "anticipation":
            end_timestamp = scene["end"] - 3
            if end_timestamp > 50:  # Near end
                memes.append({
                    "timestamp": end_timestamp,
                    "meme_id": "to_be_continued",
                    "meme_data": self.meme_database["to_be_continued"],
                    "trigger_type": "timing",
                    "scene_id": scene["id"],
                    "confidence": 0.95
                })
        
        # Peak tension moments
        intensity = scene.get("intensity", 0)
        if intensity > 0.9:
            memes.append({
                "timestamp": scene["start"],
                "meme_id": "dramatic_zoom",
                "meme_data": self.meme_database["dramatic_zoom"],
                "trigger_type": "timing",
                "scene_id": scene["id"],
                "confidence": 0.75
            })
        
        return memes
    
    def _deduplicate_memes(self, memes: List[Dict]) -> List[Dict]:
        """
        Remove duplicate memes at similar timestamps
        """
        if not memes:
            return []
        
        deduplicated = []
        seen_timestamps = set()
        
        for meme in memes:
            timestamp_bucket = round(meme["timestamp"] / 5) * 5  # 5-second buckets
            
            if timestamp_bucket not in seen_timestamps:
                deduplicated.append(meme)
                seen_timestamps.add(timestamp_bucket)
        
        return deduplicated
    
    def _select_best_memes(self, memes: List[Dict], max_count: int) -> List[Dict]:
        """
        Select the best memes based on confidence and timing
        """
        # Sort by confidence
        memes.sort(key=lambda x: x["confidence"], reverse=True)
        
        # Take top N
        selected = memes[:max_count]
        
        # Re-sort by timestamp
        selected.sort(key=lambda x: x["timestamp"])
        
        return selected
    
    async def inject_memes(self, video: Dict, meme_opportunities: List[Dict]) -> Dict:
        """
        Inject memes into video at optimal points
        """
        for opportunity in meme_opportunities:
            timestamp = opportunity["timestamp"]
            meme_data = opportunity["meme_data"]
            
            # Find the frame closest to this timestamp
            for frame in video.get("frames", []):
                frame_start = frame.get("timestamp", 0)
                frame_end = frame_start + frame.get("duration", 5)
                
                if frame_start <= timestamp < frame_end:
                    # Inject meme into this frame
                    frame["memes"] = frame.get("memes", [])
                    frame["memes"].append({
                        "type": opportunity["meme_id"],
                        "data": meme_data,
                        "offset": timestamp - frame_start
                    })
                    break
        
        video["memes_injected"] = True
        video["meme_count"] = len(meme_opportunities)
        
        return video
    
    async def generate_viral_catchphrase(self, script: Dict, mode: str) -> str:
        """
        Generate a potential viral catchphrase
        """
        mode_catchphrases = {
            "reality": [
                "Let me tell you why that's INSANE",
                "And that's when everything changed",
                "You won't believe what happened next",
                "This is NOT what I expected"
            ],
            "novela": [
                "My heart will never be the same",
                "How could this happen to us?",
                "Love is a battlefield",
                "The truth always comes out"
            ],
            "terror": [
                "It was RIGHT THERE",
                "Don't look behind you",
                "Some things should stay hidden",
                "The nightmare was just beginning"
            ],
            "music-video": [
                "This is MY moment",
                "Feel the energy",
                "We're just getting started",
                "Watch me shine"
            ]
        }
        
        catchphrases = mode_catchphrases.get(mode, mode_catchphrases["reality"])
        
        # Select based on script emotion
        return catchphrases[0]  # Can be made more sophisticated
    
    async def analyze_trending_memes(self) -> List[Dict]:
        """
        Fetch current trending memes (would integrate with social APIs)
        """
        # Simulated trending memes
        trending = [
            {
                "format": "standing_here",
                "popularity": 0.95,
                "context": "realizing_moment"
            },
            {
                "format": "whos_gonna_tell_him",
                "popularity": 0.88,
                "context": "dramatic_irony"
            },
            {
                "format": "ratio",
                "popularity": 0.82,
                "context": "comeback"
            }
        ]
        
        return trending
    
    def calculate_meme_timing_score(self, injected_memes: List[Dict], emotional_arc: Dict) -> float:
        """
        Calculate how well memes align with emotional peaks
        """
        if not injected_memes:
            return 0.0
        
        score = 0.0
        peak_moments = emotional_arc.get("peak_moments", [])
        
        for meme in injected_memes:
            timestamp = meme["timestamp"]
            
            # Check proximity to peaks
            for peak in peak_moments:
                distance = abs(timestamp - peak)
                if distance < 5:  # Within 5 seconds
                    alignment = 1.0 - (distance / 5.0)
                    score += alignment * 0.3
        
        # Confidence bonus
        avg_confidence = sum(m["confidence"] for m in injected_memes) / len(injected_memes)
        score += avg_confidence * 0.4
        
        # Variety bonus
        unique_types = len(set(m["meme_id"] for m in injected_memes))
        variety = min(unique_types / 5.0, 0.3)
        score += variety
        
        return min(score, 1.0)
