from typing import Dict, List, Any
import math


class EmotionalArcArchitect:
    """
    Agent responsible for planning and controlling emotional arcs
    """
    
    def __init__(self):
        self.arc_types = {
            "30-day": self._build_30_day_arc,
            "60-day": self._build_60_day_arc,
            "90-day": self._build_90_day_arc
        }
    
    async def plan_arc(self, scenes: List[Dict], arc_duration: str, mode: str) -> Dict[str, Any]:
        """
        Plan emotional arc for content series
        """
        arc_builder = self.arc_types.get(arc_duration, self._build_30_day_arc)
        arc_data = await arc_builder(scenes, mode)
        
        return {
            "arc_duration": arc_duration,
            "mode": mode,
            "tension_curve": arc_data["tension_curve"],
            "peak_moments": arc_data["peak_moments"],
            "narrator_triggers": arc_data["narrator_triggers"],
            "episode_structure": arc_data["episode_structure"],
            "emotional_beats": arc_data["emotional_beats"]
        }
    
    async def _build_30_day_arc(self, scenes: List[Dict], mode: str) -> Dict:
        """
        30-day arc: Weekly tension peaks
        """
        # 4 weeks = 4 major peaks
        episodes = 4
        
        tension_curve = self._generate_tension_curve(
            scenes,
            peak_count=episodes,
            intensity_multiplier=1.0
        )
        
        return {
            "tension_curve": tension_curve,
            "peak_moments": [7, 15, 30, 50],  # Timestamps for peaks
            "narrator_triggers": [0, 30, 55],  # Cold open, mid-peak, end hook
            "episode_structure": {
                "week_1": {"theme": "introduction", "intensity": 0.6},
                "week_2": {"theme": "complication", "intensity": 0.75},
                "week_3": {"theme": "crisis", "intensity": 0.9},
                "week_4": {"theme": "resolution", "intensity": 0.7}
            },
            "emotional_beats": self._calculate_emotional_beats(scenes)
        }
    
    async def _build_60_day_arc(self, scenes: List[Dict], mode: str) -> Dict:
        """
        60-day arc: Bi-weekly climaxes (4 major, 4 minor peaks)
        """
        major_peaks = 4
        minor_peaks = 4
        
        tension_curve = self._generate_multi_peak_curve(
            scenes,
            major_peaks=major_peaks,
            minor_peaks=minor_peaks,
            intensity_multiplier=1.1
        )
        
        return {
            "tension_curve": tension_curve,
            "peak_moments": [5, 12, 20, 28, 35, 43, 50, 58],
            "narrator_triggers": [0, 28, 58],
            "episode_structure": {
                "phase_1": {"weeks": [1, 2], "theme": "setup", "intensity": 0.6},
                "phase_2": {"weeks": [3, 4], "theme": "development", "intensity": 0.75},
                "phase_3": {"weeks": [5, 6], "theme": "complication", "intensity": 0.85},
                "phase_4": {"weeks": [7, 8], "theme": "climax", "intensity": 0.95}
            },
            "emotional_beats": self._calculate_emotional_beats(scenes)
        }
    
    async def _build_90_day_arc(self, scenes: List[Dict], mode: str) -> Dict:
        """
        90-day arc: Monthly crescendos (3 major acts)
        """
        acts = 3
        
        tension_curve = self._generate_act_structure_curve(
            scenes,
            acts=acts,
            intensity_multiplier=1.2
        )
        
        return {
            "tension_curve": tension_curve,
            "peak_moments": [20, 40, 55],  # End of each month
            "narrator_triggers": [0, 20, 40, 58],
            "episode_structure": {
                "act_1": {
                    "duration": "Month 1",
                    "theme": "ordinary_world_disruption",
                    "intensity": 0.7,
                    "climax": 20
                },
                "act_2": {
                    "duration": "Month 2",
                    "theme": "trials_and_escalation",
                    "intensity": 0.9,
                    "climax": 40
                },
                "act_3": {
                    "duration": "Month 3",
                    "theme": "final_confrontation",
                    "intensity": 0.98,
                    "climax": 55
                }
            },
            "emotional_beats": self._calculate_emotional_beats(scenes)
        }
    
    def _generate_tension_curve(
        self,
        scenes: List[Dict],
        peak_count: int,
        intensity_multiplier: float
    ) -> List[float]:
        """
        Generate smooth tension curve with peaks
        """
        duration = sum(s["end"] - s["start"] for s in scenes)
        points = int(duration / 5)  # Sample every 5 seconds
        
        curve = []
        for i in range(points):
            t = i / points
            
            # Base sinusoidal wave with peaks
            base = 0.3 + 0.4 * math.sin(t * math.pi * peak_count)
            
            # Add overall crescendo
            crescendo = 0.3 * t
            
            # Combine and apply multiplier
            tension = min((base + crescendo) * intensity_multiplier, 1.0)
            curve.append(tension)
        
        return curve
    
    def _generate_multi_peak_curve(
        self,
        scenes: List[Dict],
        major_peaks: int,
        minor_peaks: int,
        intensity_multiplier: float
    ) -> List[float]:
        """
        Generate tension curve with both major and minor peaks
        """
        duration = sum(s["end"] - s["start"] for s in scenes)
        points = int(duration / 5)
        
        curve = []
        for i in range(points):
            t = i / points
            
            # Major peaks (larger amplitude)
            major = 0.5 * math.sin(t * math.pi * major_peaks)
            
            # Minor peaks (smaller amplitude, higher frequency)
            minor = 0.2 * math.sin(t * math.pi * (major_peaks + minor_peaks))
            
            # Base tension
            base = 0.3
            
            # Overall crescendo
            crescendo = 0.3 * t
            
            tension = min((base + major + minor + crescendo) * intensity_multiplier, 1.0)
            curve.append(max(tension, 0.2))  # Minimum tension floor
        
        return curve
    
    def _generate_act_structure_curve(
        self,
        scenes: List[Dict],
        acts: int,
        intensity_multiplier: float
    ) -> List[float]:
        """
        Generate three-act structure tension curve
        """
        duration = sum(s["end"] - s["start"] for s in scenes)
        points = int(duration / 5)
        
        curve = []
        for i in range(points):
            t = i / points
            
            # Three-act structure
            if t < 0.33:  # Act 1: Rising action
                tension = 0.4 + 0.3 * (t / 0.33)
            elif t < 0.66:  # Act 2: Complications
                local_t = (t - 0.33) / 0.33
                tension = 0.7 + 0.2 * math.sin(local_t * math.pi * 2)
            else:  # Act 3: Climax and resolution
                local_t = (t - 0.66) / 0.34
                tension = 0.9 + 0.1 * math.sin(local_t * math.pi)
            
            tension = min(tension * intensity_multiplier, 1.0)
            curve.append(tension)
        
        return curve
    
    def _calculate_emotional_beats(self, scenes: List[Dict]) -> List[Dict]:
        """
        Identify specific emotional beats throughout the arc
        """
        beats = []
        
        for scene in scenes:
            beats.append({
                "timestamp": (scene["start"] + scene["end"]) / 2,
                "scene_id": scene["id"],
                "emotion": scene.get("emotion", "neutral"),
                "intensity": scene.get("intensity", 0.5),
                "description": scene.get("description", "")
            })
        
        return beats
    
    def calculate_emotional_variance(self, tension_curve: List[float]) -> float:
        """
        Calculate variance in emotional intensity
        """
        if not tension_curve:
            return 0.0
        
        mean = sum(tension_curve) / len(tension_curve)
        variance = sum((x - mean) ** 2 for x in tension_curve) / len(tension_curve)
        
        return variance
    
    def identify_pacing_issues(self, tension_curve: List[float]) -> List[Dict]:
        """
        Identify potential pacing problems
        """
        issues = []
        
        # Check for flat sections (low variance over time)
        window_size = 5
        for i in range(len(tension_curve) - window_size):
            window = tension_curve[i:i + window_size]
            variance = sum((x - sum(window)/len(window)) ** 2 for x in window) / len(window)
            
            if variance < 0.01:  # Too flat
                issues.append({
                    "timestamp": i * 5,
                    "type": "flat_pacing",
                    "severity": "medium",
                    "recommendation": "Increase emotional variance in this section"
                })
        
        # Check for missing peaks
        max_tension = max(tension_curve)
        if max_tension < 0.75:
            issues.append({
                "type": "missing_climax",
                "severity": "high",
                "recommendation": "Add a clear emotional peak"
            })
        
        return issues
    
    def optimize_narrator_placement(
        self,
        tension_curve: List[float],
        existing_triggers: List[int]
    ) -> List[int]:
        """
        Optimize narrator trigger placements based on tension curve
        """
        optimal_triggers = [0]  # Always start with cold open
        
        # Find high-tension moments for mid-point narration
        mid_point = len(tension_curve) // 2
        mid_section = tension_curve[mid_point - 5:mid_point + 5]
        if mid_section:
            peak_index = mid_section.index(max(mid_section))
            optimal_triggers.append((mid_point - 5 + peak_index) * 5)
        
        # End hook at final high point
        end_section = tension_curve[-10:]
        if end_section:
            peak_index = end_section.index(max(end_section))
            optimal_triggers.append((len(tension_curve) - 10 + peak_index) * 5)
        
        return optimal_triggers
