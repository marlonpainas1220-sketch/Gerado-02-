from typing import Dict, List, Any, Optional
import asyncio


class SarcasticNarratorAgent:
    """
    Agent that generates witty, observational narrator commentary
    """
    
    def __init__(self):
        self.narrator_styles = {
            "sarcastic": self._sarcastic_style,
            "dramatic": self._dramatic_style,
            "comedic": self._comedic_style,
            "mystery": self._mystery_style
        }
        self.default_style = "sarcastic"
    
    async def generate_narration(
        self,
        script: Dict,
        emotional_arc: Dict,
        mode: str,
        voice_reference: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Generate narrator script for key moments
        """
        narrator_triggers = emotional_arc.get("narrator_triggers", [0, 30, 55])
        scenes = script.get("scenes", [])
        
        narration = {
            "style": self.default_style,
            "voice_reference": voice_reference,
            "lines": []
        }
        
        # Generate line for each trigger point
        for trigger_time in narrator_triggers:
            context = self._get_context_at_timestamp(trigger_time, scenes, emotional_arc)
            line = await self._generate_line(context, mode)
            
            narration["lines"].append({
                "timestamp": trigger_time,
                "text": line,
                "duration": self._estimate_duration(line),
                "context": context["moment_type"]
            })
        
        return narration
    
    def _get_context_at_timestamp(
        self,
        timestamp: float,
        scenes: List[Dict],
        arc: Dict
    ) -> Dict:
        """
        Get narrative context at specific timestamp
        """
        # Find scene at this timestamp
        current_scene = None
        for scene in scenes:
            if scene["start"] <= timestamp < scene["end"]:
                current_scene = scene
                break
        
        if not current_scene:
            current_scene = scenes[0] if scenes else {}
        
        # Determine moment type
        if timestamp < 5:
            moment_type = "cold_open"
        elif timestamp > 50:
            moment_type = "cliffhanger"
        else:
            moment_type = "peak_tension"
        
        return {
            "timestamp": timestamp,
            "moment_type": moment_type,
            "emotion": current_scene.get("emotion", "neutral"),
            "intensity": current_scene.get("intensity", 0.5),
            "description": current_scene.get("description", "")
        }
    
    async def _generate_line(self, context: Dict, mode: str) -> str:
        """
        Generate a narrator line based on context
        """
        moment_type = context["moment_type"]
        emotion = context["emotion"]
        
        style_func = self.narrator_styles.get(
            self.default_style,
            self._sarcastic_style
        )
        
        return await style_func(moment_type, emotion, mode)
    
    async def _sarcastic_style(
        self,
        moment_type: str,
        emotion: str,
        mode: str
    ) -> str:
        """
        Generate sarcastic commentary
        """
        templates = {
            "cold_open": {
                "reality": [
                    "Oh, you're gonna love this one.",
                    "So this is what we're doing today, huh?",
                    "Let me tell you how this goes wrong.",
                    "Buckle up, it gets worse."
                ],
                "novela": [
                    "Another day, another dramatic revelation.",
                    "Love? In THIS economy?",
                    "Oh honey, you have no idea.",
                    "This is fine. Everything is fine."
                ],
                "terror": [
                    "Yeah, this won't end well.",
                    "Spoiler: it's behind you.",
                    "Classic mistake, really.",
                    "What could possibly go wrong?"
                ]
            },
            "peak_tension": {
                "reality": [
                    "And here comes the drama.",
                    "Oh, this is where it gets good.",
                    "Remember when things were simple?",
                    "Plot twist incoming."
                ],
                "novela": [
                    "The tears are real, folks.",
                    "Someone call a therapist.",
                    "Love hurts, apparently.",
                    "This is peak telenovela right here."
                ],
                "terror": [
                    "Don't say I didn't warn you.",
                    "It's always the basement.",
                    "Why do they never run?",
                    "The suspense is killing me. Literally."
                ]
            },
            "cliffhanger": {
                "reality": [
                    "Wait until you see what happens next.",
                    "And there it is.",
                    "To be continued, obviously.",
                    "You're welcome for that ending."
                ],
                "novela": [
                    "And they say romance is dead.",
                    "The plot thickens...",
                    "Stay tuned for more heartbreak.",
                    "Will love prevail? Probably not."
                ],
                "terror": [
                    "Sleep tight, I guess.",
                    "It's not over. It's never over.",
                    "Check under your bed tonight.",
                    "Sweet dreams are made of this."
                ]
            }
        }
        
        mode_templates = templates.get(moment_type, {})
        lines = mode_templates.get(mode, mode_templates.get("reality", []))
        
        if not lines:
            return "Well, that happened."
        
        # Return first line (can be randomized)
        return lines[0]
    
    async def _dramatic_style(
        self,
        moment_type: str,
        emotion: str,
        mode: str
    ) -> str:
        """
        Generate dramatic commentary
        """
        templates = {
            "cold_open": "In a world where nothing is as it seems...",
            "peak_tension": "This... changes everything.",
            "cliffhanger": "But fate had other plans."
        }
        
        return templates.get(moment_type, "And so it begins.")
    
    async def _comedic_style(
        self,
        moment_type: str,
        emotion: str,
        mode: str
    ) -> str:
        """
        Generate comedic commentary
        """
        templates = {
            "cold_open": "Now watch this...",
            "peak_tension": "This is the part where it gets weird.",
            "cliffhanger": "And that's how you break the internet."
        }
        
        return templates.get(moment_type, "Classic.")
    
    async def _mystery_style(
        self,
        moment_type: str,
        emotion: str,
        mode: str
    ) -> str:
        """
        Generate mysterious commentary
        """
        templates = {
            "cold_open": "The truth lies beneath the surface...",
            "peak_tension": "But what they didn't know was...",
            "cliffhanger": "Some mysteries are never solved."
        }
        
        return templates.get(moment_type, "The question remains...")
    
    def _estimate_duration(self, text: str) -> float:
        """
        Estimate speaking duration based on text length
        """
        # Average speaking rate: ~150 words per minute
        # ~2.5 words per second
        words = len(text.split())
        duration = words / 2.5
        
        # Add padding for dramatic pauses
        duration *= 1.3
        
        # Cap at 3 seconds max
        return min(duration, 3.0)
    
    async def synthesize_voice(
        self,
        text: str,
        voice_reference: Optional[str] = None,
        style: str = "sarcastic"
    ) -> Dict[str, Any]:
        """
        Generate voice audio from text
        (Would integrate with voice synthesis API)
        """
        # Simulated voice synthesis
        await asyncio.sleep(0.3)
        
        voice_config = {
            "text": text,
            "voice_reference": voice_reference,
            "style": style,
            "speed": 1.0,
            "pitch": 1.0,
            "output_file": f"narrator_{hash(text)}.mp3"
        }
        
        # Style-specific adjustments
        if style == "sarcastic":
            voice_config["pitch"] = 0.95  # Slightly lower
            voice_config["speed"] = 1.1   # Slightly faster
        elif style == "dramatic":
            voice_config["pitch"] = 0.9
            voice_config["speed"] = 0.85
        
        return voice_config
    
    async def add_narration_to_video(
        self,
        video: Dict,
        narration: Dict
    ) -> Dict:
        """
        Integrate narrator audio into video
        """
        for line in narration["lines"]:
            timestamp = line["timestamp"]
            
            # Synthesize voice
            voice_audio = await self.synthesize_voice(
                line["text"],
                narration.get("voice_reference"),
                narration["style"]
            )
            
            # Find frame and add audio
            for frame in video.get("frames", []):
                frame_start = frame.get("timestamp", 0)
                frame_end = frame_start + frame.get("duration", 5)
                
                if frame_start <= timestamp < frame_end:
                    frame["narration"] = {
                        "audio": voice_audio["output_file"],
                        "text": line["text"],
                        "offset": timestamp - frame_start,
                        "duration": line["duration"]
                    }
                    
                    # Duck background music when narration plays
                    if "audio" in frame:
                        frame["audio"]["music_volume"] = 0.3
                    
                    break
        
        video["narration_applied"] = True
        return video
    
    def calculate_narrator_impact(self, narration: Dict) -> float:
        """
        Calculate how much narrator adds to engagement
        """
        if not narration or not narration.get("lines"):
            return 0.0
        
        impact = 0.0
        
        # Number of narration points
        line_count = len(narration["lines"])
        impact += min(line_count / 3.0, 0.4)
        
        # Timing quality (spread across video)
        timestamps = [line["timestamp"] for line in narration["lines"]]
        if len(timestamps) >= 2:
            spread = max(timestamps) - min(timestamps)
            if spread > 40:  # Well distributed
                impact += 0.3
        
        # Style bonus
        if narration.get("style") == "sarcastic":
            impact += 0.2  # Sarcastic is most engaging
        
        # Voice reference bonus
        if narration.get("voice_reference"):
            impact += 0.1
        
        return min(impact, 1.0)
    
    def optimize_placement(
        self,
        narration: Dict,
        emotional_arc: Dict
    ) -> Dict:
        """
        Optimize narrator placement for maximum impact
        """
        tension_curve = emotional_arc.get("tension_curve", [])
        if not tension_curve:
            return narration
        
        # Find optimal moments: after peaks for commentary
        optimal_timestamps = []
        
        # Cold open (always)
        optimal_timestamps.append(0)
        
        # Find tension peaks
        for i in range(1, len(tension_curve) - 1):
            if tension_curve[i] > tension_curve[i-1] and tension_curve[i] > tension_curve[i+1]:
                # This is a peak
                timestamp = i * 5 + 2  # 2 seconds after peak
                optimal_timestamps.append(timestamp)
        
        # Cliffhanger (always near end)
        optimal_timestamps.append(max(len(tension_curve) * 5 - 5, 55))
        
        # Keep only top 3 moments
        optimal_timestamps = sorted(optimal_timestamps)[:3]
        
        # Update narration timestamps
        for i, line in enumerate(narration.get("lines", [])):
            if i < len(optimal_timestamps):
                line["timestamp"] = optimal_timestamps[i]
        
        narration["optimized"] = True
        return narration
