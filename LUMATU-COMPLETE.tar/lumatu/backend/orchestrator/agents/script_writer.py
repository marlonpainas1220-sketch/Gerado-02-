from typing import Dict, List, Any
import asyncio


class ScriptWriterAgent:
    """
    Agent responsible for generating coherent stories and scripts
    """
    
    def __init__(self):
        self.mode_templates = {
            "reality": self._reality_template,
            "novela": self._novela_template,
            "terror": self._terror_template,
            "music-video": self._music_video_template
        }
    
    async def generate_script(self, mode: str, context: Dict) -> Dict[str, Any]:
        """
        Generate script based on mode and context
        """
        template_func = self.mode_templates.get(mode, self._reality_template)
        script = await template_func(context)
        
        return {
            "mode": mode,
            "scenes": script["scenes"],
            "total_duration": sum(s["end"] - s["start"] for s in script["scenes"]),
            "narrative_arc": script["arc"],
            "key_moments": script["key_moments"]
        }
    
    async def _reality_template(self, context: Dict) -> Dict:
        """
        Reality show script template
        """
        return {
            "arc": "conflict_resolution",
            "scenes": [
                {
                    "id": 1,
                    "start": 0,
                    "end": 5,
                    "description": "Avatar enters frame, direct address to camera",
                    "dialogue": "You won't believe what just happened...",
                    "emotion": "intrigue",
                    "intensity": 0.6,
                    "camera": "close_up"
                },
                {
                    "id": 2,
                    "start": 5,
                    "end": 15,
                    "description": "Flashback to conflict setup",
                    "dialogue": "It all started when...",
                    "emotion": "tension_rising",
                    "intensity": 0.7,
                    "camera": "medium_shot"
                },
                {
                    "id": 3,
                    "start": 15,
                    "end": 35,
                    "description": "Peak drama moment - confrontation",
                    "dialogue": "And then I said...",
                    "emotion": "climax",
                    "intensity": 0.95,
                    "camera": "dramatic_zoom"
                },
                {
                    "id": 4,
                    "start": 35,
                    "end": 50,
                    "description": "Emotional reaction and processing",
                    "dialogue": "I couldn't believe it...",
                    "emotion": "reflection",
                    "intensity": 0.75,
                    "camera": "close_up"
                },
                {
                    "id": 5,
                    "start": 50,
                    "end": 60,
                    "description": "Cliffhanger hook for next episode",
                    "dialogue": "But wait until you hear what happens next...",
                    "emotion": "anticipation",
                    "intensity": 0.8,
                    "camera": "pull_back"
                }
            ],
            "key_moments": [3, 25, 55]
        }
    
    async def _novela_template(self, context: Dict) -> Dict:
        """
        Novela script template with romantic drama
        """
        return {
            "arc": "romantic_tension",
            "scenes": [
                {
                    "id": 1,
                    "start": 0,
                    "end": 8,
                    "description": "Avatar in contemplation, soft lighting",
                    "dialogue": "I never thought love could hurt this much...",
                    "emotion": "melancholy",
                    "intensity": 0.65,
                    "camera": "soft_focus"
                },
                {
                    "id": 2,
                    "start": 8,
                    "end": 25,
                    "description": "Flashback to romantic moment",
                    "dialogue": "When we first met...",
                    "emotion": "passion",
                    "intensity": 0.85,
                    "camera": "romantic_lighting"
                },
                {
                    "id": 3,
                    "start": 25,
                    "end": 45,
                    "description": "Betrayal revealed - dramatic music swell",
                    "dialogue": "How could you?",
                    "emotion": "heartbreak",
                    "intensity": 0.98,
                    "camera": "intense_close_up"
                },
                {
                    "id": 4,
                    "start": 45,
                    "end": 60,
                    "description": "Emotional resolution and new hope",
                    "dialogue": "But maybe there's still a chance...",
                    "emotion": "hope",
                    "intensity": 0.7,
                    "camera": "hopeful_angle"
                }
            ],
            "key_moments": [15, 30, 50]
        }
    
    async def _terror_template(self, context: Dict) -> Dict:
        """
        Terror/horror script template
        """
        return {
            "arc": "escalating_dread",
            "scenes": [
                {
                    "id": 1,
                    "start": 0,
                    "end": 5,
                    "description": "Normal scene, false sense of security",
                    "dialogue": "Everything seems fine...",
                    "emotion": "calm",
                    "intensity": 0.3,
                    "camera": "steady"
                },
                {
                    "id": 2,
                    "start": 5,
                    "end": 15,
                    "description": "First signs of something wrong",
                    "dialogue": "Wait... did you hear that?",
                    "emotion": "unease",
                    "intensity": 0.6,
                    "camera": "shaky"
                },
                {
                    "id": 3,
                    "start": 15,
                    "end": 35,
                    "description": "Building dread, darkness closing in",
                    "dialogue": "No... no no no...",
                    "emotion": "fear",
                    "intensity": 0.85,
                    "camera": "unstable"
                },
                {
                    "id": 4,
                    "start": 35,
                    "end": 50,
                    "description": "Peak terror moment - the reveal",
                    "dialogue": "[screaming]",
                    "emotion": "terror",
                    "intensity": 0.99,
                    "camera": "chaotic"
                },
                {
                    "id": 5,
                    "start": 50,
                    "end": 60,
                    "description": "Ambiguous ending, lingering dread",
                    "dialogue": "It's not over...",
                    "emotion": "dread",
                    "intensity": 0.8,
                    "camera": "ominous"
                }
            ],
            "key_moments": [8, 28, 45]
        }
    
    async def _music_video_template(self, context: Dict) -> Dict:
        """
        Music video script with lip sync focus
        """
        return {
            "arc": "visual_storytelling",
            "scenes": [
                {
                    "id": 1,
                    "start": 0,
                    "end": 15,
                    "description": "Opening shot, avatar performing with perfect lip sync",
                    "dialogue": "[lyrics synced]",
                    "emotion": "energetic",
                    "intensity": 0.7,
                    "camera": "dynamic_tracking"
                },
                {
                    "id": 2,
                    "start": 15,
                    "end": 30,
                    "description": "Verse performance with style changes",
                    "dialogue": "[lyrics synced]",
                    "emotion": "expressive",
                    "intensity": 0.75,
                    "camera": "multiple_angles"
                },
                {
                    "id": 3,
                    "start": 30,
                    "end": 45,
                    "description": "Chorus - high energy, perfect sync",
                    "dialogue": "[chorus synced]",
                    "emotion": "peak_energy",
                    "intensity": 0.95,
                    "camera": "sweeping"
                },
                {
                    "id": 4,
                    "start": 45,
                    "end": 60,
                    "description": "Bridge and outro with visual effects",
                    "dialogue": "[lyrics synced]",
                    "emotion": "crescendo",
                    "intensity": 0.9,
                    "camera": "stylized"
                }
            ],
            "key_moments": [10, 30, 50]
        }
    
    def split_into_frames(self, scenes: List[Dict], fps: int = 30) -> List[Dict]:
        """
        Convert scenes into individual frame specifications
        """
        frames = []
        
        for scene in scenes:
            duration = scene["end"] - scene["start"]
            frame_count = int(duration * fps)
            
            for i in range(frame_count):
                timestamp = scene["start"] + (i / fps)
                frames.append({
                    "frame_number": len(frames),
                    "timestamp": timestamp,
                    "scene_id": scene["id"],
                    "description": scene["description"],
                    "emotion": scene["emotion"],
                    "intensity": scene["intensity"],
                    "camera": scene.get("camera", "default")
                })
        
        return frames
