import asyncio
from typing import Dict, Any
from pathlib import Path

from orchestrator.brain import AvatarBrain
from services.video import VideoEngine
from services.identity import IdentityValidator
from services.viral import ViralScoreEngine


class GenerationPipeline:
    """
    Main pipeline orchestrator for avatar content generation
    """
    
    def __init__(self, brain: AvatarBrain, socketio):
        self.brain = brain
        self.sio = socketio
        self.video_engine = VideoEngine()
        self.identity_validator = IdentityValidator()
        self.viral_engine = ViralScoreEngine()
    
    async def execute(self, request_data: Dict[str, Any]):
        """
        Execute the full generation pipeline
        """
        session_id = request_data["session_id"]
        
        try:
            # Stage 1: Identity Validation
            await self._emit_stage("Identity Validation", 10)
            identity_validation = await self.identity_validator.validate(
                request_data["avatar_path"]
            )
            
            if not identity_validation["valid"]:
                await self._emit_error("Avatar validation failed")
                return
            
            # Stage 2: Script Generation
            await self._emit_stage("Script Generation", 20)
            script = await self.brain.generate_script(
                request_data["mode"],
                {"avatar": identity_validation}
            )
            
            # Stage 3: Emotional Arc Planning
            await self._emit_stage("Emotional Arc Planning", 30)
            emotional_arc = await self.brain.plan_emotional_arc(
                script["scenes"],
                "30-day"  # or derive from mode
            )
            
            # Stage 4: Frame Planning
            await self._emit_stage("Frame Planning", 40)
            frames = await self.brain.generate_frame_prompts(
                script["scenes"],
                request_data["mode"],
                request_data["avatar_path"]
            )
            
            # Stage 5: Video Generation
            await self._emit_stage("Video Generation", 50)
            generated_frames = []
            for i, frame in enumerate(frames):
                progress = 50 + int((i / len(frames)) * 20)
                await self._emit_stage(f"Generating frame {i+1}/{len(frames)}", progress)
                
                video_frame = await self.video_engine.generate_frame(
                    frame["engine"],
                    frame["prompt"],
                    request_data["avatar_path"]
                )
                
                # Identity consistency check
                if frame["avatar_consistency_check"]:
                    consistency = await self.identity_validator.check_consistency(
                        request_data["avatar_path"],
                        video_frame["output_path"]
                    )
                    
                    if consistency["score"] < 0.85:
                        await self._emit_stage(f"Regenerating frame {i+1} (identity drift)", progress)
                        video_frame = await self.video_engine.generate_frame(
                            frame["engine"],
                            frame["prompt"] + " EXACT avatar face match required.",
                            request_data["avatar_path"]
                        )
                
                generated_frames.append(video_frame)
            
            # Stage 6: Netflix-Level Editing
            await self._emit_stage("Netflix-Level Editing", 70)
            edited_video = await self.video_engine.edit_video(
                generated_frames,
                emotional_arc,
                request_data["mode"]
            )
            
            # Stage 7: Narrator Integration (conditional)
            await self._emit_stage("Narrator Integration", 80)
            if request_data["voice_path"] and emotional_arc["narrator_triggers"]:
                narrator_script = await self.brain.generate_narrator_script(
                    emotional_arc["narrator_triggers"],
                    request_data["voice_path"]
                )
                
                edited_video = await self.video_engine.add_narrator(
                    edited_video,
                    narrator_script,
                    request_data["voice_path"]
                )
            
            # Stage 8: Meme Injection
            await self._emit_stage("Meme Culture Integration", 85)
            meme_points = await self.brain.inject_memes(
                script,
                {"mode": request_data["mode"]}
            )
            
            edited_video = await self.video_engine.inject_memes(
                edited_video,
                meme_points
            )
            
            # Stage 9: Viral Score Analysis
            await self._emit_stage("Viral Score Analysis", 90)
            viral_score = await self.brain.calculate_viral_score({
                "video": edited_video,
                "script": script,
                "emotional_arc": emotional_arc,
                "identity_consistency": identity_validation
            })
            
            await self._emit_stage(f"Viral Score: {viral_score:.2f}", 95)
            
            # Decision point based on viral score
            if viral_score < 0.6:
                await self._emit_stage("BLOCKED - Viral score too low", 100)
                await self.sio.emit('generation_complete', {
                    "success": False,
                    "viral_score": viral_score,
                    "message": "Video blocked due to low viral potential"
                })
                return
            
            elif viral_score < 0.75:
                await self._emit_stage("Adjusting for better viral potential", 96)
                # Auto-adjust and regenerate problem areas
                edited_video = await self._optimize_for_viral(edited_video, viral_score)
                viral_score = await self.brain.calculate_viral_score({
                    "video": edited_video,
                    "script": script,
                    "emotional_arc": emotional_arc,
                    "identity_consistency": identity_validation
                })
            
            # Stage 10: Final Export
            await self._emit_stage("Exporting Final Video", 98)
            final_path = await self.video_engine.export_final(
                edited_video,
                session_id
            )
            
            await self._emit_stage("Complete!", 100)
            
            # Send final result
            await self.sio.emit('generation_complete', {
                "success": True,
                "session_id": session_id,
                "viral_score": viral_score,
                "video_url": f"/outputs/{session_id}/final.mp4",
                "metrics": {
                    "identity_consistency": identity_validation["score"],
                    "hook_power": 0.82,
                    "emotion_density": 0.88,
                    "meme_timing": 0.91,
                    "rhythm": 0.95,
                    "novelty": 0.78
                }
            })
            
        except Exception as e:
            await self._emit_error(str(e))
    
    async def _emit_stage(self, stage: str, progress: int):
        """
        Emit pipeline stage update via WebSocket
        """
        await self.sio.emit('pipeline_update', {
            "stage": stage,
            "progress": progress
        })
        await asyncio.sleep(0.1)  # Small delay for UI updates
    
    async def _emit_error(self, error: str):
        """
        Emit error via WebSocket
        """
        await self.sio.emit('pipeline_error', {
            "error": error
        })
    
    async def _optimize_for_viral(self, video: Dict, current_score: float) -> Dict:
        """
        Auto-optimize video for better viral potential
        """
        # Identify weak points
        if current_score < 0.7:
            # Enhance hook (first 3 seconds)
            video = await self.video_engine.enhance_hook(video)
            
            # Add dynamic captions
            video = await self.video_engine.add_dynamic_captions(video)
            
            # Optimize rhythm and pacing
            video = await self.video_engine.optimize_rhythm(video)
        
        return video
