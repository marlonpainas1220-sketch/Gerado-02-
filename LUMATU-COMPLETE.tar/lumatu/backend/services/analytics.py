from typing import Dict, List, Any
from datetime import datetime
import json
from pathlib import Path


class PerformanceMonitor:
    """
    Monitor and analyze LUMATU system performance
    """
    
    def __init__(self):
        self.metrics_file = Path("metrics.jsonl")
        self.sessions = {}
    
    def start_session(self, session_id: str, request_data: Dict) -> None:
        """
        Start tracking a generation session
        """
        self.sessions[session_id] = {
            "session_id": session_id,
            "start_time": datetime.now().isoformat(),
            "request": request_data,
            "stages": [],
            "errors": [],
            "metrics": {}
        }
    
    def log_stage(
        self,
        session_id: str,
        stage_name: str,
        duration: float,
        metadata: Dict = None
    ) -> None:
        """
        Log completion of a pipeline stage
        """
        if session_id not in self.sessions:
            return
        
        self.sessions[session_id]["stages"].append({
            "name": stage_name,
            "duration": duration,
            "timestamp": datetime.now().isoformat(),
            "metadata": metadata or {}
        })
    
    def log_error(self, session_id: str, error: str, stage: str) -> None:
        """
        Log an error during generation
        """
        if session_id not in self.sessions:
            return
        
        self.sessions[session_id]["errors"].append({
            "error": error,
            "stage": stage,
            "timestamp": datetime.now().isoformat()
        })
    
    def complete_session(
        self,
        session_id: str,
        viral_score: float,
        final_metrics: Dict
    ) -> None:
        """
        Mark session as complete and save metrics
        """
        if session_id not in self.sessions:
            return
        
        session = self.sessions[session_id]
        session["end_time"] = datetime.now().isoformat()
        session["viral_score"] = viral_score
        session["metrics"] = final_metrics
        
        # Calculate total duration
        start = datetime.fromisoformat(session["start_time"])
        end = datetime.fromisoformat(session["end_time"])
        session["total_duration"] = (end - start).total_seconds()
        
        # Save to file
        self._save_metrics(session)
        
        # Clean up
        del self.sessions[session_id]
    
    def _save_metrics(self, session: Dict) -> None:
        """
        Save session metrics to file
        """
        with self.metrics_file.open("a") as f:
            f.write(json.dumps(session) + "\n")
    
    def get_analytics(self) -> Dict[str, Any]:
        """
        Get analytics from all recorded sessions
        """
        if not self.metrics_file.exists():
            return {}
        
        sessions = []
        with self.metrics_file.open("r") as f:
            for line in f:
                sessions.append(json.loads(line))
        
        if not sessions:
            return {}
        
        # Calculate aggregates
        total_sessions = len(sessions)
        successful = len([s for s in sessions if not s["errors"]])
        
        viral_scores = [s["viral_score"] for s in sessions if "viral_score" in s]
        avg_viral_score = sum(viral_scores) / len(viral_scores) if viral_scores else 0
        
        durations = [s["total_duration"] for s in sessions if "total_duration" in s]
        avg_duration = sum(durations) / len(durations) if durations else 0
        
        # Mode distribution
        modes = [s["request"]["mode"] for s in sessions if "request" in s]
        mode_counts = {}
        for mode in modes:
            mode_counts[mode] = mode_counts.get(mode, 0) + 1
        
        # Stage performance
        stage_durations = {}
        for session in sessions:
            for stage in session.get("stages", []):
                name = stage["name"]
                if name not in stage_durations:
                    stage_durations[name] = []
                stage_durations[name].append(stage["duration"])
        
        stage_avg = {
            name: sum(durations) / len(durations)
            for name, durations in stage_durations.items()
        }
        
        return {
            "total_sessions": total_sessions,
            "successful_sessions": successful,
            "success_rate": successful / total_sessions if total_sessions > 0 else 0,
            "average_viral_score": avg_viral_score,
            "average_duration": avg_duration,
            "mode_distribution": mode_counts,
            "stage_performance": stage_avg,
            "high_viral_rate": len([s for s in viral_scores if s >= 0.75]) / len(viral_scores) if viral_scores else 0
        }
    
    def export_report(self, output_file: str = "performance_report.json") -> None:
        """
        Export analytics report
        """
        analytics = self.get_analytics()
        
        with open(output_file, "w") as f:
            json.dump(analytics, f, indent=2)


class ViralAnalytics:
    """
    Analyze viral score patterns and trends
    """
    
    def __init__(self):
        self.metrics_file = Path("metrics.jsonl")
    
    def analyze_viral_patterns(self) -> Dict[str, Any]:
        """
        Analyze what makes content viral
        """
        if not self.metrics_file.exists():
            return {}
        
        sessions = []
        with self.metrics_file.open("r") as f:
            for line in f:
                sessions.append(json.loads(line))
        
        viral_sessions = [s for s in sessions if s.get("viral_score", 0) >= 0.75]
        low_viral = [s for s in sessions if s.get("viral_score", 0) < 0.6]
        
        # Compare viral vs non-viral
        patterns = {
            "viral_characteristics": self._extract_characteristics(viral_sessions),
            "low_viral_characteristics": self._extract_characteristics(low_viral),
            "success_factors": self._identify_success_factors(viral_sessions, low_viral)
        }
        
        return patterns
    
    def _extract_characteristics(self, sessions: List[Dict]) -> Dict:
        """
        Extract common characteristics from sessions
        """
        if not sessions:
            return {}
        
        characteristics = {
            "avg_identity_consistency": 0,
            "avg_hook_power": 0,
            "avg_meme_count": 0,
            "common_modes": {},
            "narrator_usage": 0
        }
        
        for session in sessions:
            metrics = session.get("metrics", {})
            characteristics["avg_identity_consistency"] += metrics.get("identity_consistency", 0)
            characteristics["avg_hook_power"] += metrics.get("hook_power", 0)
            
            mode = session.get("request", {}).get("mode", "unknown")
            characteristics["common_modes"][mode] = characteristics["common_modes"].get(mode, 0) + 1
        
        # Average
        count = len(sessions)
        characteristics["avg_identity_consistency"] /= count
        characteristics["avg_hook_power"] /= count
        
        return characteristics
    
    def _identify_success_factors(
        self,
        viral_sessions: List[Dict],
        low_viral: List[Dict]
    ) -> List[str]:
        """
        Identify what differentiates viral from non-viral
        """
        factors = []
        
        if not viral_sessions or not low_viral:
            return factors
        
        # Compare metrics
        viral_chars = self._extract_characteristics(viral_sessions)
        low_chars = self._extract_characteristics(low_viral)
        
        if viral_chars["avg_hook_power"] > low_chars["avg_hook_power"] + 0.15:
            factors.append("Strong hook power is critical")
        
        if viral_chars["avg_identity_consistency"] > low_chars["avg_identity_consistency"] + 0.1:
            factors.append("Identity consistency matters")
        
        return factors
    
    def recommend_improvements(self, session_metrics: Dict) -> List[str]:
        """
        Recommend improvements based on session metrics
        """
        recommendations = []
        
        viral_score = session_metrics.get("viral_score", 0)
        metrics = session_metrics.get("metrics", {})
        
        if viral_score < 0.75:
            # Identify weak areas
            if metrics.get("hook_power", 0) < 0.7:
                recommendations.append("Improve opening hook: add pattern interrupt in first 2 seconds")
            
            if metrics.get("identity_consistency", 0) < 0.85:
                recommendations.append("Enhance identity consistency: use stricter prompts")
            
            if metrics.get("meme_timing", 0) < 0.7:
                recommendations.append("Better meme placement: align with emotional peaks")
            
            if metrics.get("rhythm", 0) < 0.7:
                recommendations.append("Optimize pacing: faster cuts during high tension")
        
        return recommendations


class ABTestingFramework:
    """
    Framework for A/B testing different generation strategies
    """
    
    def __init__(self):
        self.experiments = {}
    
    def create_experiment(
        self,
        name: str,
        variants: List[Dict]
    ) -> str:
        """
        Create a new A/B test experiment
        """
        experiment_id = f"exp_{hash(name)}"
        
        self.experiments[experiment_id] = {
            "name": name,
            "variants": variants,
            "results": {v["id"]: [] for v in variants},
            "start_time": datetime.now().isoformat()
        }
        
        return experiment_id
    
    def log_result(
        self,
        experiment_id: str,
        variant_id: str,
        viral_score: float
    ) -> None:
        """
        Log result for a variant
        """
        if experiment_id not in self.experiments:
            return
        
        self.experiments[experiment_id]["results"][variant_id].append(viral_score)
    
    def analyze_experiment(self, experiment_id: str) -> Dict:
        """
        Analyze experiment results
        """
        if experiment_id not in self.experiments:
            return {}
        
        experiment = self.experiments[experiment_id]
        results = experiment["results"]
        
        analysis = {}
        for variant_id, scores in results.items():
            if not scores:
                continue
            
            analysis[variant_id] = {
                "avg_viral_score": sum(scores) / len(scores),
                "sample_size": len(scores),
                "viral_rate": len([s for s in scores if s >= 0.75]) / len(scores)
            }
        
        # Determine winner
        if analysis:
            winner = max(analysis.items(), key=lambda x: x[1]["avg_viral_score"])
            analysis["winner"] = winner[0]
        
        return analysis
