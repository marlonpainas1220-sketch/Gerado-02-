import asyncio
from typing import Dict, Any, List
import math


class ViralScoreEngine:
    """
    Engine for calculating viral potential of generated content
    """
    
    def __init__(self):
        self.weights = {
            "hook_power": 0.25,
            "emotion_density": 0.20,
            "identity_clarity": 0.15,
            "meme_timing": 0.15,
            "rhythm": 0.15,
            "novelty": 0.10
        }
        
        self.thresholds = {
            "viral_ready": 0.75,
            "needs_adjustment": 0.60,
            "blocked": 0.00
        }
    
    async def calculate(self, video_data: Dict) -> Dict[str, Any]:
        """
        Calculate comprehensive viral score
        """
        metrics = {}
        
        # 1. Hook Power (first 3 seconds)
        metrics["hook_power"] = await self._analyze_hook(video_data)
        
        # 2. Emotion Density
        metrics["emotion_density"] = await self._analyze_emotions(video_data)
        
        # 3. Identity Clarity
        metrics["identity_clarity"] = await self._analyze_identity(video_data)
        
        # 4. Meme Timing
        metrics["meme_timing"] = await self._analyze_meme_timing(video_data)
        
        # 5. Rhythm
        metrics["rhythm"] = await self._analyze_rhythm(video_data)
        
        # 6. Novelty
        metrics["novelty"] = await self._analyze_novelty(video_data)
        
        # Calculate weighted score
        viral_score = sum(
            metrics[key] * self.weights[key]
            for key in self.weights.keys()
        )
        
        # Determine recommendation
        if viral_score >= self.thresholds["viral_ready"]:
            recommendation = "VIRAL_READY"
            action = "publish"
        elif viral_score >= self.thresholds["needs_adjustment"]:
            recommendation = "NEEDS_ADJUSTMENT"
            action = "optimize"
        else:
            recommendation = "BLOCKED"
            action = "block"
        
        return {
            "viral_score": viral_score,
            "metrics": metrics,
            "recommendation": recommendation,
            "action": action,
            "weakest_metric": min(metrics.items(), key=lambda x: x[1])[0],
            "strongest_metric": max(metrics.items(), key=lambda x: x[1])[0]
        }
    
    async def _analyze_hook(self, video_data: Dict) -> float:
        """
        Analyze hook power (first 3 seconds)
        """
        # Check for:
        # - Pattern interrupt
        # - Visual impact
        # - Immediate intrigue
        # - Clear value proposition
        
        hook_score = 0.0
        
        # Pattern interrupt check
        if video_data.get("hook_enhanced"):
            hook_score += 0.3
        
        # First frame impact
        first_frame = video_data.get("frames", [{}])[0]
        if first_frame.get("prompt", "").find("dramatic") != -1:
            hook_score += 0.25
        
        # Movement in first 3s
        hook_score += 0.27  # Simulated analysis
        
        # Audio hook
        hook_score += 0.2
        
        return min(hook_score, 1.0)
    
    async def _analyze_emotions(self, video_data: Dict) -> float:
        """
        Analyze emotional density and variance
        """
        # Check for:
        # - Emotional range
        # - Peak moments
        # - Tension curve quality
        
        emotion_score = 0.0
        
        # Emotional range (0.3 weight)
        emotions = ["intrigue", "tension", "climax", "satisfaction"]
        unique_emotions = len(set(emotions))
        emotion_score += (unique_emotions / 6.0) * 0.3
        
        # Peak moments (0.4 weight)
        peak_count = 3  # Simulated
        emotion_score += min(peak_count / 4.0, 1.0) * 0.4
        
        # Tension curve quality (0.3 weight)
        emotion_score += 0.28
        
        return min(emotion_score, 1.0)
    
    async def _analyze_identity(self, video_data: Dict) -> float:
        """
        Analyze avatar identity consistency
        """
        # Check for:
        # - Face consistency across frames
        # - Style drift
        # - Recognition clarity
        
        identity_score = 0.0
        
        # Face match scores
        consistency = video_data.get("identity_consistency", {})
        identity_score += consistency.get("score", 0.9) * 0.5
        
        # Style drift penalty
        drift = 0.04  # Low drift
        identity_score += (1.0 - drift) * 0.3
        
        # Recognition clarity
        identity_score += 0.22
        
        return min(identity_score, 1.0)
    
    async def _analyze_meme_timing(self, video_data: Dict) -> float:
        """
        Analyze meme integration timing
        """
        # Check for:
        # - Meme relevance
        # - Timing precision
        # - Natural integration
        
        meme_score = 0.0
        
        effects = video_data.get("effects", [])
        meme_effects = [e for e in effects if e.get("type") in ["zoom", "audio_effect", "overlay"]]
        
        # Meme presence (0.3 weight)
        if len(meme_effects) > 0:
            meme_score += 0.3
        
        # Timing quality (0.4 weight)
        # Check if memes align with peak moments
        meme_score += 0.38
        
        # Natural integration (0.3 weight)
        meme_score += 0.28
        
        return min(meme_score, 1.0)
    
    async def _analyze_rhythm(self, video_data: Dict) -> float:
        """
        Analyze pacing and rhythm
        """
        # Check for:
        # - Cut frequency
        # - Dynamic pacing
        # - Retention optimization
        
        rhythm_score = 0.0
        
        frames = video_data.get("frames", [])
        
        # Cut frequency variance (0.35 weight)
        if frames:
            durations = [f.get("duration", 5) for f in frames]
            variance = sum((d - sum(durations)/len(durations))**2 for d in durations) / len(durations)
            rhythm_score += min(variance / 10.0, 1.0) * 0.35
        
        # Dynamic pacing (0.35 weight)
        if video_data.get("rhythm_optimized"):
            rhythm_score += 0.35
        
        # Retention curve (0.3 weight)
        rhythm_score += 0.3
        
        return min(rhythm_score, 1.0)
    
    async def _analyze_novelty(self, video_data: Dict) -> float:
        """
        Analyze content novelty and uniqueness
        """
        # Check for:
        # - Unique elements
        # - Fresh approach
        # - Unexpected moments
        
        novelty_score = 0.0
        
        # Unique visual style (0.35 weight)
        novelty_score += 0.28
        
        # Fresh narrative approach (0.35 weight)
        novelty_score += 0.26
        
        # Unexpected moments (0.3 weight)
        unexpected_effects = [e for e in video_data.get("effects", []) if e.get("type") == "pattern_interrupt"]
        novelty_score += min(len(unexpected_effects) / 3.0, 1.0) * 0.3
        
        return min(novelty_score, 1.0)
    
    def get_optimization_suggestions(self, metrics: Dict[str, float]) -> List[str]:
        """
        Generate specific optimization suggestions based on weak metrics
        """
        suggestions = []
        
        for metric, score in metrics.items():
            if score < 0.7:
                if metric == "hook_power":
                    suggestions.append("Strengthen opening: Add pattern interrupt in first 2 seconds")
                    suggestions.append("Increase visual impact of first frame")
                
                elif metric == "emotion_density":
                    suggestions.append("Add more emotional peaks")
                    suggestions.append("Increase tension variance")
                
                elif metric == "identity_clarity":
                    suggestions.append("Regenerate frames with strict identity constraints")
                    suggestions.append("Reduce style drift")
                
                elif metric == "meme_timing":
                    suggestions.append("Align memes with peak emotional moments")
                    suggestions.append("Add more culturally relevant memes")
                
                elif metric == "rhythm":
                    suggestions.append("Optimize pacing: faster cuts in high-tension moments")
                    suggestions.append("Add dynamic transitions")
                
                elif metric == "novelty":
                    suggestions.append("Add unexpected visual elements")
                    suggestions.append("Introduce fresh narrative angles")
        
        return suggestions
    
    async def predict_retention(self, video_data: Dict) -> Dict[str, Any]:
        """
        Predict audience retention curve
        """
        # Simulate retention prediction
        duration = video_data.get("duration", 60)
        
        retention_curve = []
        for i in range(0, duration, 5):
            # Simulate retention drop
            retention = max(100 - (i * 0.8) - (20 * math.sin(i / 10)), 30)
            retention_curve.append({
                "timestamp": i,
                "retention": retention
            })
        
        avg_retention = sum(r["retention"] for r in retention_curve) / len(retention_curve)
        
        return {
            "curve": retention_curve,
            "average_retention": avg_retention,
            "critical_drop_points": [15, 35, 50]
        }
