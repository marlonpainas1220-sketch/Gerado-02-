import pytest
import asyncio
from orchestrator.brain import AvatarBrain
from orchestrator.pipeline import GenerationPipeline
from services.identity import IdentityValidator
from services.viral import ViralScoreEngine
from orchestrator.agents.script_writer import ScriptWriterAgent
from orchestrator.agents.emotional_arc import EmotionalArcArchitect


class TestIdentityValidator:
    """Tests for identity validation"""
    
    @pytest.mark.asyncio
    async def test_validate_avatar(self):
        validator = IdentityValidator()
        result = await validator.validate("test_avatar.jpg")
        
        assert result["valid"] == True
        assert "avatar_id" in result
        assert result["quality_score"] >= 0.8
    
    @pytest.mark.asyncio
    async def test_consistency_check(self):
        validator = IdentityValidator()
        result = await validator.check_consistency("ref.jpg", "gen.jpg")
        
        assert "score" in result
        assert result["score"] >= 0.0 and result["score"] <= 1.0
        assert "passed" in result
    
    def test_style_drift_calculation(self):
        validator = IdentityValidator()
        frames = [{"id": i} for i in range(6)]
        drift = validator.calculate_style_drift(frames)
        
        assert drift >= 0.0
        assert drift < 0.2  # Should be low


class TestViralScoreEngine:
    """Tests for viral score calculation"""
    
    @pytest.mark.asyncio
    async def test_viral_score_calculation(self):
        engine = ViralScoreEngine()
        video_data = {
            "frames": [{"duration": 5}] * 12,
            "hook_enhanced": True,
            "rhythm_optimized": True
        }
        
        result = await engine.calculate(video_data)
        
        assert "viral_score" in result
        assert result["viral_score"] >= 0.0 and result["viral_score"] <= 1.0
        assert "recommendation" in result
        assert result["recommendation"] in ["VIRAL_READY", "NEEDS_ADJUSTMENT", "BLOCKED"]
    
    @pytest.mark.asyncio
    async def test_hook_analysis(self):
        engine = ViralScoreEngine()
        video_data = {"hook_enhanced": True, "frames": [{"prompt": "dramatic scene"}]}
        
        score = await engine._analyze_hook(video_data)
        
        assert score >= 0.0 and score <= 1.0
    
    def test_optimization_suggestions(self):
        engine = ViralScoreEngine()
        metrics = {
            "hook_power": 0.5,
            "emotion_density": 0.9,
            "identity_clarity": 0.6
        }
        
        suggestions = engine.get_optimization_suggestions(metrics)
        
        assert len(suggestions) > 0
        assert any("hook" in s.lower() for s in suggestions)


class TestScriptWriter:
    """Tests for script generation"""
    
    @pytest.mark.asyncio
    async def test_reality_script_generation(self):
        writer = ScriptWriterAgent()
        context = {"avatar": "test"}
        
        script = await writer.generate_script("reality", context)
        
        assert script["mode"] == "reality"
        assert len(script["scenes"]) > 0
        assert "narrative_arc" in script
        assert script["total_duration"] > 0
    
    @pytest.mark.asyncio
    async def test_terror_script_generation(self):
        writer = ScriptWriterAgent()
        context = {"avatar": "test"}
        
        script = await writer.generate_script("terror", context)
        
        assert script["mode"] == "terror"
        assert any(s["emotion"] == "terror" for s in script["scenes"])
    
    def test_frame_splitting(self):
        writer = ScriptWriterAgent()
        scenes = [
            {"id": 1, "start": 0, "end": 5, "description": "test", "emotion": "test", "intensity": 0.5}
        ]
        
        frames = writer.split_into_frames(scenes, fps=30)
        
        assert len(frames) == 150  # 5 seconds * 30 fps


class TestEmotionalArc:
    """Tests for emotional arc planning"""
    
    @pytest.mark.asyncio
    async def test_30_day_arc(self):
        architect = EmotionalArcArchitect()
        scenes = [
            {"id": i, "start": i*10, "end": (i+1)*10, "intensity": 0.5}
            for i in range(6)
        ]
        
        arc = await architect.plan_arc(scenes, "30-day", "reality")
        
        assert arc["arc_duration"] == "30-day"
        assert len(arc["tension_curve"]) > 0
        assert len(arc["peak_moments"]) == 4  # Weekly peaks
    
    def test_tension_curve_generation(self):
        architect = EmotionalArcArchitect()
        scenes = [{"start": 0, "end": 60}]
        
        curve = architect._generate_tension_curve(scenes, peak_count=3, intensity_multiplier=1.0)
        
        assert len(curve) > 0
        assert all(0.0 <= t <= 1.0 for t in curve)
    
    def test_emotional_variance(self):
        architect = EmotionalArcArchitect()
        tension_curve = [0.3, 0.5, 0.7, 0.9, 0.6, 0.4]
        
        variance = architect.calculate_emotional_variance(tension_curve)
        
        assert variance > 0.0


class TestAvatarBrain:
    """Tests for main orchestrator"""
    
    @pytest.mark.asyncio
    async def test_script_generation(self):
        brain = AvatarBrain()
        
        script = await brain.generate_script("reality", {"test": "context"})
        
        assert "scenes" in script
        assert len(script["scenes"]) > 0
    
    @pytest.mark.asyncio
    async def test_viral_score_calculation(self):
        brain = AvatarBrain()
        video_data = {"test": "data"}
        
        score = await brain.calculate_viral_score(video_data)
        
        assert score >= 0.0 and score <= 1.0
    
    @pytest.mark.asyncio
    async def test_frame_prompt_generation(self):
        brain = AvatarBrain()
        scenes = [
            {"id": 1, "description": "test", "emotion": "joy", "start": 0, "end": 10}
        ]
        
        frames = await brain.generate_frame_prompts(scenes, "reality", "avatar_ref.jpg")
        
        assert len(frames) > 0
        assert all("prompt" in f for f in frames)
        assert all("engine" in f for f in frames)
    
    def test_video_engine_selection(self):
        brain = AvatarBrain()
        
        assert brain._select_video_engine("music-video") == "luma"
        assert brain._select_video_engine("terror") == "pika"
        assert brain._select_video_engine("reality") == "runway"


class TestEndToEnd:
    """End-to-end integration tests"""
    
    @pytest.mark.asyncio
    async def test_pipeline_identity_validation(self):
        brain = AvatarBrain()
        validator = IdentityValidator()
        
        # Simulate identity check
        validation = await validator.validate("test.jpg")
        assert validation["valid"] == True
    
    @pytest.mark.asyncio
    async def test_pipeline_viral_threshold(self):
        engine = ViralScoreEngine()
        
        # High score video
        high_score_video = {
            "frames": [{"duration": 5}] * 12,
            "hook_enhanced": True,
            "rhythm_optimized": True,
            "effects": [{"type": "zoom"}, {"type": "overlay"}]
        }
        
        result = await engine.calculate(high_score_video)
        assert result["viral_score"] > 0.6
        
        # Low score video
        low_score_video = {"frames": [{"duration": 5}] * 12}
        result = await engine.calculate(low_score_video)
        # Should still calculate but may be lower


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
