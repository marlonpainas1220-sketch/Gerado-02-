'use client'

import { Upload, Image as ImageIcon } from 'lucide-react'
import { useState, useRef } from 'react'

interface AvatarUploadProps {
  avatar: File | null
  onUpload: (file: File) => void
}

export default function AvatarUpload({ avatar, onUpload }: AvatarUploadProps) {
  const [preview, setPreview] = useState<string | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file && file.type.startsWith('image/')) {
      onUpload(file)
      const reader = new FileReader()
      reader.onload = (e) => {
        setPreview(e.target?.result as string)
      }
      reader.readAsDataURL(file)
    }
  }

  return (
    <div className="space-y-4">
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        onChange={handleFileChange}
        className="hidden"
      />

      {preview ? (
        <div className="relative">
          <img
            src={preview}
            alt="Avatar preview"
            className="w-full h-64 object-cover rounded-lg border-2 border-google-blue"
          />
          <button
            onClick={() => fileInputRef.current?.click()}
            className="absolute top-2 right-2 bg-white rounded-full p-2 shadow-lg hover:bg-gray-50"
          >
            <Upload className="w-5 h-5 text-google-blue" />
          </button>
        </div>
      ) : (
        <button
          onClick={() => fileInputRef.current?.click()}
          className="w-full h-64 border-2 border-dashed border-gray-300 rounded-lg flex flex-col items-center justify-center hover:border-google-blue hover:bg-blue-50 transition-all"
        >
          <ImageIcon className="w-12 h-12 text-gray-400 mb-3" />
          <p className="text-sm text-gray-600 font-medium">Click to upload avatar</p>
          <p className="text-xs text-gray-400 mt-1">PNG, JPG up to 10MB</p>
        </button>
      )}

      {avatar && (
        <div className="text-sm text-gray-600">
          ✓ {avatar.name} ({(avatar.size / 1024 / 1024).toFixed(2)} MB)
        </div>
      )}
    </div>
  )
}
