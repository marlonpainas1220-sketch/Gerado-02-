'use client'

import { Download, TrendingUp, Eye, Zap } from 'lucide-react'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts'

interface DashboardProps {
  viralScore: number
  videoUrl: string | null
  pipelineData: any
}

export default function Dashboard({ viralScore, videoUrl, pipelineData }: DashboardProps) {
  const emotionData = [
    { frame: 0, tension: 0.2 },
    { frame: 10, tension: 0.4 },
    { frame: 20, tension: 0.7 },
    { frame: 30, tension: 0.9 },
    { frame: 40, tension: 0.6 },
    { frame: 50, tension: 0.8 },
    { frame: 60, tension: 0.95 },
  ]

  const getScoreColor = (score: number) => {
    if (score >= 0.75) return 'text-google-green'
    if (score >= 0.6) return 'text-google-yellow'
    return 'text-google-red'
  }

  const getScoreLabel = (score: number) => {
    if (score >= 0.75) return 'VIRAL READY'
    if (score >= 0.6) return 'NEEDS ADJUSTMENT'
    return 'BLOCKED'
  }

  return (
    <div className="space-y-6">
      {/* Viral Score Gauge */}
      <div className="bg-white rounded-lg border border-gray-200 p-6 shadow-sm">
        <h2 className="text-xl font-semibold text-gray-900 mb-6">Viral Score</h2>
        
        <div className="flex items-center justify-center mb-6">
          <div className="relative">
            <svg className="w-48 h-48 transform -rotate-90">
              <circle
                cx="96"
                cy="96"
                r="88"
                stroke="#e5e7eb"
                strokeWidth="12"
                fill="none"
              />
              <circle
                cx="96"
                cy="96"
                r="88"
                stroke={viralScore >= 0.75 ? '#34A853' : viralScore >= 0.6 ? '#FBBC04' : '#EA4335'}
                strokeWidth="12"
                fill="none"
                strokeDasharray={`${viralScore * 552.92} 552.92`}
                className="viral-gauge"
              />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className={`text-5xl font-bold ${getScoreColor(viralScore)}`}>
                {(viralScore * 100).toFixed(0)}
              </span>
              <span className="text-sm text-gray-500 mt-1">/ 100</span>
            </div>
          </div>
        </div>

        <div className={`text-center font-semibold text-lg ${getScoreColor(viralScore)}`}>
          {getScoreLabel(viralScore)}
        </div>

        <div className="grid grid-cols-3 gap-4 mt-6">
          <div className="text-center">
            <div className="text-2xl font-bold text-gray-900">92%</div>
            <div className="text-xs text-gray-500 mt-1">Identity</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-gray-900">88%</div>
            <div className="text-xs text-gray-500 mt-1">Emotion</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-gray-900">95%</div>
            <div className="text-xs text-gray-500 mt-1">Rhythm</div>
          </div>
        </div>
      </div>

      {/* Emotional Arc */}
      <div className="bg-white rounded-lg border border-gray-200 p-6 shadow-sm">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">Emotional Arc</h2>
        <ResponsiveContainer width="100%" height={200}>
          <LineChart data={emotionData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
            <XAxis dataKey="frame" stroke="#9ca3af" />
            <YAxis stroke="#9ca3af" />
            <Tooltip />
            <Line
              type="monotone"
              dataKey="tension"
              stroke="#4285F4"
              strokeWidth={3}
              dot={{ fill: '#4285F4', r: 4 }}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>

      {/* Metrics */}
      <div className="grid grid-cols-2 gap-4">
        <div className="bg-white rounded-lg border border-gray-200 p-4 shadow-sm">
          <div className="flex items-center gap-2 mb-2">
            <TrendingUp className="w-5 h-5 text-google-blue" />
            <span className="text-sm text-gray-600">Hook Power</span>
          </div>
          <div className="text-2xl font-bold text-gray-900">0.82</div>
        </div>

        <div className="bg-white rounded-lg border border-gray-200 p-4 shadow-sm">
          <div className="flex items-center gap-2 mb-2">
            <Zap className="w-5 h-5 text-google-yellow" />
            <span className="text-sm text-gray-600">Meme Timing</span>
          </div>
          <div className="text-2xl font-bold text-gray-900">0.91</div>
        </div>
      </div>

      {/* Video Download */}
      {videoUrl && (
        <div className="bg-gradient-to-r from-google-blue to-google-green rounded-lg p-6 shadow-lg">
          <h3 className="text-white font-semibold mb-4">Final Video Ready</h3>
          <a
            href={videoUrl}
            download
            className="flex items-center justify-center gap-2 bg-white text-google-blue font-semibold py-3 px-6 rounded-lg hover:shadow-lg transition-all"
          >
            <Download className="w-5 h-5" />
            Download Video
          </a>
        </div>
      )}
    </div>
  )
}
