'use client'

import { CheckCircle, Circle, Loader2 } from 'lucide-react'

interface PipelineStage {
  name: string
  status: 'pending' | 'active' | 'complete'
  progress?: number
  message?: string
}

interface GenerationPanelProps {
  status: string
  pipelineData: any
}

export default function GenerationPanel({ status, pipelineData }: GenerationPanelProps) {
  const stages: PipelineStage[] = [
    { name: 'Identity Validation', status: 'complete' },
    { name: 'Script Generation', status: 'complete' },
    { name: 'Emotional Arc Planning', status: 'active', progress: 65 },
    { name: 'Frame Planning', status: 'pending' },
    { name: 'Video Generation', status: 'pending' },
    { name: 'Netflix-Level Editing', status: 'pending' },
    { name: 'Narrator Integration', status: 'pending' },
    { name: 'Viral Score Analysis', status: 'pending' },
  ]

  return (
    <div className="bg-white rounded-lg border border-gray-200 p-6 shadow-sm">
      <h2 className="text-xl font-semibold text-gray-900 mb-6">
        Generation Pipeline
      </h2>

      <div className="space-y-4">
        {stages.map((stage, index) => (
          <div key={index} className="flex items-start gap-3">
            <div className="mt-1">
              {stage.status === 'complete' && (
                <CheckCircle className="w-5 h-5 text-google-green" />
              )}
              {stage.status === 'active' && (
                <Loader2 className="w-5 h-5 text-google-blue animate-spin" />
              )}
              {stage.status === 'pending' && (
                <Circle className="w-5 h-5 text-gray-300" />
              )}
            </div>

            <div className="flex-1">
              <div className="flex items-center justify-between">
                <h3
                  className={`text-sm font-medium ${
                    stage.status === 'pending'
                      ? 'text-gray-400'
                      : 'text-gray-900'
                  }`}
                >
                  {stage.name}
                </h3>
                {stage.progress !== undefined && (
                  <span className="text-xs text-google-blue font-semibold">
                    {stage.progress}%
                  </span>
                )}
              </div>

              {stage.progress !== undefined && (
                <div className="mt-2 h-1.5 bg-gray-200 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-google-blue to-google-green transition-all duration-500"
                    style={{ width: `${stage.progress}%` }}
                  />
                </div>
              )}

              {stage.message && (
                <p className="text-xs text-gray-500 mt-1">{stage.message}</p>
              )}
            </div>
          </div>
        ))}
      </div>

      <div className="mt-6 p-4 bg-blue-50 rounded-lg">
        <p className="text-sm text-gray-700">
          <span className="font-semibold text-google-blue">Current:</span>{' '}
          {status || 'Initializing pipeline...'}
        </p>
      </div>
    </div>
  )
}
