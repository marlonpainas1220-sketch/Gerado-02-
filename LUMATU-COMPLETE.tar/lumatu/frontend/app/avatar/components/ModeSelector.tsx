'use client'

import { Tv, Heart, Ghost, Music } from 'lucide-react'
import type { Mode } from '../page'

interface ModeSelectorProps {
  selectedMode: Mode | null
  onSelect: (mode: Mode) => void
}

const modes = [
  {
    id: 'reality' as Mode,
    name: 'Reality Show',
    icon: Tv,
    color: 'blue',
    description: 'Drama, conflicts, and emotional moments',
  },
  {
    id: 'novela' as Mode,
    name: 'Novela',
    icon: Heart,
    color: 'red',
    description: 'Romantic storytelling with dramatic arcs',
  },
  {
    id: 'terror' as Mode,
    name: 'Terror',
    icon: Ghost,
    color: 'yellow',
    description: 'Horror content with tension and suspense',
  },
  {
    id: 'music-video' as Mode,
    name: 'Music Video',
    icon: Music,
    color: 'green',
    description: 'Perfect lip-sync music videos',
  },
]

export default function ModeSelector({ selectedMode, onSelect }: ModeSelectorProps) {
  return (
    <div className="grid grid-cols-2 gap-4">
      {modes.map((mode) => {
        const Icon = mode.icon
        const isSelected = selectedMode === mode.id
        const colorMap = {
          blue: 'border-google-blue bg-blue-50',
          red: 'border-google-red bg-red-50',
          yellow: 'border-google-yellow bg-yellow-50',
          green: 'border-google-green bg-green-50',
        }

        return (
          <button
            key={mode.id}
            onClick={() => onSelect(mode.id)}
            className={`p-4 rounded-lg border-2 transition-all text-left ${
              isSelected
                ? colorMap[mode.color]
                : 'border-gray-200 hover:border-gray-300'
            }`}
          >
            <Icon
              className={`w-8 h-8 mb-2 ${
                isSelected ? `text-google-${mode.color}` : 'text-gray-400'
              }`}
            />
            <h3 className="font-semibold text-gray-900">{mode.name}</h3>
            <p className="text-xs text-gray-500 mt-1">{mode.description}</p>
          </button>
        )
      })}
    </div>
  )
}
