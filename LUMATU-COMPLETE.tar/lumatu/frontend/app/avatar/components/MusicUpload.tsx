'use client'

import { Music, Upload } from 'lucide-react'
import { useRef } from 'react'

interface MusicUploadProps {
  music: File | null
  onUpload: (file: File) => void
}

export default function MusicUpload({ music, onUpload }: MusicUploadProps) {
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file && file.type.startsWith('audio/')) {
      onUpload(file)
    }
  }

  return (
    <div className="space-y-4">
      <input
        ref={fileInputRef}
        type="file"
        accept="audio/*"
        onChange={handleFileChange}
        className="hidden"
      />

      <button
        onClick={() => fileInputRef.current?.click()}
        className="w-full h-32 border-2 border-dashed border-google-green rounded-lg flex flex-col items-center justify-center hover:border-google-blue hover:bg-blue-50 transition-all"
      >
        <Music className="w-10 h-10 text-gray-400 mb-2" />
        <p className="text-sm text-gray-600 font-medium">Upload music track</p>
        <p className="text-xs text-gray-400 mt-1">MP3, WAV, M4A</p>
      </button>

      {music && (
        <div className="flex items-center gap-2 text-sm text-gray-600 bg-blue-50 p-3 rounded-lg">
          <Music className="w-4 h-4 text-google-blue" />
          <span>✓ {music.name} ({(music.size / 1024 / 1024).toFixed(2)} MB)</span>
        </div>
      )}
    </div>
  )
}
