import { useEffect, useState } from 'react'
import { io, Socket } from 'socket.io-client'

export function useWebSocket(isActive: boolean) {
  const [socket, setSocket] = useState<Socket | null>(null)
  const [status, setStatus] = useState<string>('')
  const [pipelineData, setPipelineData] = useState<any>(null)

  useEffect(() => {
    if (!isActive) return

    const newSocket = io('http://localhost:8000', {
      transports: ['websocket'],
    })

    newSocket.on('connect', () => {
      console.log('WebSocket connected')
    })

    newSocket.on('pipeline_update', (data) => {
      setStatus(data.stage)
      setPipelineData(data)
    })

    newSocket.on('disconnect', () => {
      console.log('WebSocket disconnected')
    })

    setSocket(newSocket)

    return () => {
      newSocket.close()
    }
  }, [isActive])

  return { status, pipelineData }
}
