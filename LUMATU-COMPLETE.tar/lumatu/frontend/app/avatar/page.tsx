'use client'

import { useState } from 'react'
import AvatarUpload from './components/AvatarUpload'
import VoiceUpload from './components/VoiceUpload'
import ModeSelector from './components/ModeSelector'
import MusicUpload from './components/MusicUpload'
import GenerationPanel from './components/GenerationPanel'
import Dashboard from './components/Dashboard'
import { useWebSocket } from './hooks/useWebSocket'

export type Mode = 'reality' | 'novela' | 'terror' | 'music-video'

export interface GenerationState {
  avatarImage: File | null
  voiceReference: File | null
  mode: Mode | null
  musicFile: File | null
  isGenerating: boolean
  progress: number
  currentStage: string
  viralScore: number | null
  finalVideo: string | null
}

export default function AvatarPage() {
  const [state, setState] = useState<GenerationState>({
    avatarImage: null,
    voiceReference: null,
    mode: null,
    musicFile: null,
    isGenerating: false,
    progress: 0,
    currentStage: '',
    viralScore: null,
    finalVideo: null,
  })

  const { status, pipelineData } = useWebSocket(state.isGenerating)

  const updateState = (updates: Partial<GenerationState>) => {
    setState(prev => ({ ...prev, ...updates }))
  }

  const canGenerate = state.avatarImage && state.mode && 
    (state.mode !== 'music-video' || state.musicFile)

  const handleGenerate = async () => {
    if (!canGenerate) return

    updateState({ isGenerating: true, progress: 0 })

    const formData = new FormData()
    formData.append('avatar', state.avatarImage!)
    if (state.voiceReference) formData.append('voice', state.voiceReference)
    formData.append('mode', state.mode!)
    if (state.musicFile) formData.append('music', state.musicFile)

    try {
      const response = await fetch('http://localhost:8000/api/generate', {
        method: 'POST',
        body: formData,
      })

      const data = await response.json()
      
      if (data.success) {
        updateState({
          viralScore: data.viral_score,
          finalVideo: data.video_url,
        })
      }
    } catch (error) {
      console.error('Generation failed:', error)
    } finally {
      updateState({ isGenerating: false })
    }
  }

  return (
    <div className="min-h-screen bg-white">
      <header className="border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <h1 className="text-4xl font-bold bg-gradient-to-r from-google-blue to-google-green bg-clip-text text-transparent">
            LUMATU
          </h1>
          <p className="text-gray-600 mt-2">AI Avatar Content Generator</p>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Input Panel */}
          <div className="space-y-6">
            <section className="bg-white rounded-lg border border-gray-200 p-6 shadow-sm">
              <h2 className="text-xl font-semibold text-gray-900 mb-4">
                1. Upload Avatar
              </h2>
              <AvatarUpload
                avatar={state.avatarImage}
                onUpload={(file) => updateState({ avatarImage: file })}
              />
            </section>

            <section className="bg-white rounded-lg border border-gray-200 p-6 shadow-sm">
              <h2 className="text-xl font-semibold text-gray-900 mb-4">
                2. Voice Reference (Optional)
              </h2>
              <VoiceUpload
                voice={state.voiceReference}
                onUpload={(file) => updateState({ voiceReference: file })}
              />
            </section>

            <section className="bg-white rounded-lg border border-gray-200 p-6 shadow-sm">
              <h2 className="text-xl font-semibold text-gray-900 mb-4">
                3. Choose Mode
              </h2>
              <ModeSelector
                selectedMode={state.mode}
                onSelect={(mode) => updateState({ mode })}
              />
            </section>

            {state.mode === 'music-video' && (
              <section className="bg-white rounded-lg border border-gray-200 p-6 shadow-sm">
                <h2 className="text-xl font-semibold text-gray-900 mb-4">
                  4. Upload Music
                </h2>
                <MusicUpload
                  music={state.musicFile}
                  onUpload={(file) => updateState({ musicFile: file })}
                />
              </section>
            )}

            <button
              onClick={handleGenerate}
              disabled={!canGenerate || state.isGenerating}
              className="w-full py-4 px-6 rounded-lg font-semibold text-white transition-all disabled:opacity-50 disabled:cursor-not-allowed gradient-bg hover:shadow-lg"
            >
              {state.isGenerating ? 'Generating...' : 'Generate'}
            </button>
          </div>

          {/* Generation Panel */}
          <div className="space-y-6">
            {state.isGenerating && (
              <GenerationPanel
                status={status}
                pipelineData={pipelineData}
              />
            )}

            {state.viralScore !== null && (
              <Dashboard
                viralScore={state.viralScore}
                videoUrl={state.finalVideo}
                pipelineData={pipelineData}
              />
            )}
          </div>
        </div>
      </main>
    </div>
  )
}
